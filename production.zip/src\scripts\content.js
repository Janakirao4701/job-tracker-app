(function () {
  if (document.getElementById('rjd-sidebar')) return;

  // ── CONFIG ──
  let GEMINI_KEY = ''; // loaded from storage
  const SUPABASE_URL  = CONFIG.SUPABASE_URL;
  const SUPABASE_KEY  = CONFIG.SUPABASE_KEY;

  const STATUSES = ['Applied','Interview Scheduled','Interview Done','Offer','Rejected','Skipped'];
  const STATUS_COLORS = {
    'Applied':             { bg: '#eef2ff', color: '#4f46e5' },
    'Interview Scheduled': { bg: '#ecfdf5', color: '#059669' },
    'Interview Done':      { bg: '#fffbeb', color: '#d97706' },
    'Offer':               { bg: '#d1fae5', color: '#065f46' },
    'Rejected':            { bg: '#fef2f2', color: '#dc2626' },
    'Skipped':             { bg: '#f1f5f9', color: '#94a3b8' },
  };

  let currentUser         = null; // { id, email, name }
  let sessionToken        = null;
  let sessionRefreshToken = null;
  let applications = [];
  let filterStatus = 'all';
  let filterSearch = '';
  let filterDate   = '';
  let currentDetailId = null;
  let currentTab = 'tracker'; // tracker | assistant
  let isSidebarOpen = false;

  // ── OFFLINE QUEUE ──
  const QUEUE_KEY = 'rjd_offline_queue';
  function getQueue(cb) {
    const s = chromeStore();
    if (s) {
      s.get(QUEUE_KEY, r => {
        if (chrome.runtime.lastError) return cb([]);
        cb(r[QUEUE_KEY] || []);
      });
    } else cb([]);
  }
  function saveQueue(queue, cb) {
    const s = chromeStore();
    if (s) {
      s.set({ [QUEUE_KEY]: queue }, () => {
        if (chrome.runtime.lastError) return;
        if (cb) cb();
      });
    }
    updateQueueBadge(queue.length);
  }
  function updateQueueBadge(count) {
    const badge = document.getElementById('rjd-queue-badge');
    if (!badge) return;
    badge.style.display = count > 0 ? 'flex' : 'none';
    badge.textContent = count;
  }
  function enqueueApp(app) {
    getQueue(queue => {
      queue.push({ app, queuedAt: Date.now() });
      saveQueue(queue);
      showToast('📶 Offline — queued (syncs when online)');
    });
  }
  async function flushQueue() {
    if (!navigator.onLine) return;
    getQueue(async queue => {
      if (!queue.length) return;
      const remaining = [];
      for (const item of queue) {
        try {
          const body = {
            id: item.app.id, username: currentUser?.id,
            company: item.app.company, job_title: item.app.jobTitle,
            url: item.app.url, jd: item.app.jd, resume: item.app.resume || '',
            status: item.app.status, date: item.app.date,
            date_raw: item.app.dateRaw, date_key: item.app.dateKey,
            notes: item.app.notes || '', follow_up_date: item.app.followUpDate || null,
          };
          const res = await sbFetch(SUPABASE_URL + '/rest/v1/applications', {
            method: 'POST',
            headers: { 'Prefer': 'return=representation' },
            body: JSON.stringify(body),
          });
          if (res.ok) {
            if (!applications.find(a => a.id === item.app.id)) applications.push(item.app);
          } else remaining.push(item);
        } catch(e) { remaining.push(item); }
      }
      saveQueue(remaining);
      if (remaining.length < queue.length) {
        renderTable();
        showToast('✓ ' + (queue.length - remaining.length) + ' queued app(s) synced');
      }
    });
  }
  // Auto-flush when coming back online
  window.addEventListener('online', () => flushQueue());

  // ── SUPABASE HELPERS ──
  function sbHeaders() {
    return {
      'Content-Type':  'application/json',
      'apikey':        SUPABASE_KEY,
      'Authorization': 'Bearer ' + (sessionToken || SUPABASE_KEY),
    };
  }

  function verifyTokenProject(token) {
    if (!isContextValid() || !token) return false;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      // The 'ref' or 'iss' usually contains the project identifier
      const projectRef = payload.ref || (payload.iss && payload.iss.includes('supabase') ? payload.iss.split('/')[2].split('.')[0] : null);
      if (projectRef && !SUPABASE_URL.includes(projectRef)) {
        AppLogger.warn('Session token project mismatch detected!', { tokenProj: projectRef, currentProj: SUPABASE_URL });
        return false;
      }
    } catch (e) { return false; }
    return true;
  }

  // --- WEB-TO-EXTENSION BRIDGE ---
  // Listen for proxy requests from the web dashboard (Vercel)
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const message = event.data;
    if (message && message.type === 'RJD_PROXY_REQUEST') {
      const { id, url, opts } = message.payload || {};
      if (!id || !url) return;

      console.log(`[AI Blaze Bridge] Proxying request to: ${url}`);
      try {
        const response = await safeSendMessage({ action: 'sb_proxy_fetch', payload: { url, opts } });
        console.log(`[AI Blaze Bridge] Background response for ${id}:`, response);
        window.postMessage({ type: 'RJD_PROXY_RESPONSE', payload: { id, response } }, '*');
      } catch (err) {
        AppLogger.error(`Bridge error for ${id}`, { message: err.message });
        window.postMessage({ type: 'RJD_PROXY_RESPONSE', payload: { id, error: err.message } }, '*');
      }
    }
  });

  // Safe chrome API helpers — detect extension reloads
  function isContextValid() {
    return typeof chrome !== 'undefined' && !!chrome.runtime && !!chrome.runtime.id;
  }

  function chromeStore() {
    if (!isContextValid()) {
      AppLogger.warn('Extension context invalidated — please refresh the page.');
      return null;
    }
    return chrome.storage.local;
  }

  // Fix #15: Single in-flight promise prevents multiple simultaneous refresh calls
  let _refreshPromise = null;

  async function safeSendMessage(message) {
    if (!isContextValid()) return null;
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage(message, response => {
          if (chrome.runtime.lastError) {
            const err = chrome.runtime.lastError.message;
            if (err.includes('No SW') || 
                err.includes('context invalidated') || 
                err.includes('message channel closed') ||
                err.includes('Receiving end does not exist')) {
              // Gracefully handle common extension lifecycle errors
              resolve(null);
            } else {
              AppLogger.warn('[AI Blaze] sendMessage error', { err });
              resolve(null);
            }
          } else {
            resolve(response);
          }
        });
      } catch (e) { 
        resolve(null); 
      }
    });
  }

  async function refreshSession() {
    if (!sessionRefreshToken || !isContextValid()) return false;
    if (_refreshPromise) return _refreshPromise; 
    
    _refreshPromise = (async () => {
      try {
        const payload = {
          url: SUPABASE_URL + '/auth/v1/token?grant_type=refresh_token',
          opts: {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_KEY },
            body: JSON.stringify({ refresh_token: sessionRefreshToken }),
          }
        };

        const response = await safeSendMessage({ action: 'sb_proxy_fetch', payload });
        
        if (response && response.ok && response.data && response.data.access_token) {
          const data = response.data;
          sessionToken = data.access_token;
          if (data.refresh_token) sessionRefreshToken = data.refresh_token;
          saveSession(sessionToken, currentUser, sessionRefreshToken);
          
          await safeSendMessage({
            action: 'session_saved',
            payload: { token: sessionToken, user: currentUser, refreshToken: sessionRefreshToken }
          });
          return true;
        }
      } catch(e) { 
        if (isContextValid()) console.warn('Token refresh failed', e); 
      } finally {
        _refreshPromise = null;
      }
      return false;
    })();
    return _refreshPromise;
  }

  async function sbFetch(url, opts) {
    if (!navigator.onLine) throw new Error('You are offline.');
    
    if (!isContextValid()) {
      showToast('AI Blaze extension was reloaded. Please refresh the page to continue.', true);
      throw new Error('Extension context invalidated');
    }

    const callProxy = async (u, o) => {
      const res = await safeSendMessage({ action: 'sb_proxy_fetch', payload: { url: u, opts: o } });
      if (!res) {
        throw new Error('Extension context invalidated — please refresh the page');
      }
      return res;
    };

    let res = await callProxy(url, opts);
    
    if (res && res.status === 401 && sessionRefreshToken) {
      const ok = await refreshSession();
      if (ok) {
        if (!opts.headers) opts.headers = {};
        opts.headers['Authorization'] = 'Bearer ' + sessionToken;
        res = await callProxy(url, opts);
      }
    }
    
    if (res && res.status === 401) {
      sessionToken = null; currentUser = null; clearSession();
      showToast('Session error — please sign out and sign in again', true);
      throw new Error('Unauthorized project or expired session');
    }
    
    if (!res || !res.ok) {
      throw new Error((res && res.data && res.data.message) || 'Request failed');
    }
    
    return {
      ok: res.ok,
      status: res.status,
      json: async () => res.data
    };
  }

  // ── RESUME PROFILE DB SYNC ──
  async function saveResumeProfileDB(profile) {
    if (!currentUser) return false;
    try {
      const res = await sbFetch(`${SUPABASE_URL}/rest/v1/user_settings?on_conflict=username`, {
        method: 'POST',
        headers: { 
          'apikey': SUPABASE_KEY, 
          'Authorization': 'Bearer ' + sessionToken,
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates,return=representation'
        },
        body: JSON.stringify({ username: currentUser.id, resume_profile: profile })
      });
      if (res && res.ok) {
        localStorage.setItem('rjd_resume_profile', JSON.stringify(profile));
        const s = chromeStore();
        if (s) s.set({ rjd_resume_profile: profile }, () => { if (chrome.runtime.lastError) return; });
        return true;
      }
    } catch(e) { console.warn('Save profile failed', e); }
    return false;
  }

  async function loadResumeProfileDB() {
    if (!currentUser) return {};
    try {
      const res = await sbFetch(
        `${SUPABASE_URL}/rest/v1/user_settings?username=eq.${currentUser.id}&select=resume_profile`,
        { headers: { 'apikey': SUPABASE_KEY, 'Authorization': 'Bearer ' + sessionToken } }
      );
      if (res && res.ok) {
        const data = await res.json();
        if (data && data[0] && data[0].resume_profile) {
          const profile = data[0].resume_profile;
          localStorage.setItem('rjd_resume_profile', JSON.stringify(profile));
          const s = chromeStore();
          if (s) s.set({ rjd_resume_profile: profile }, () => { if (chrome.runtime.lastError) return; });
          return profile;
        }
      }
    } catch(e) {
      if (e.message && e.message.includes('Extension context invalidated')) {
        // Silently fail if context is lost - a toast is already shown by sbFetch
      } else {
        console.warn('Load resume profile from DB failed:', e);
      }
    }
    // Fallback to local
    const s2 = chromeStore();
    return new Promise(resolve => {
      if (s2) {
        s2.get('rjd_resume_profile', r => {
          if (chrome.runtime.lastError) {
            resolve(JSON.parse(localStorage.getItem('rjd_resume_profile') || '{}'));
            return;
          }
          resolve(r.rjd_resume_profile || JSON.parse(localStorage.getItem('rjd_resume_profile') || '{}'));
        });
      } else resolve(JSON.parse(localStorage.getItem('rjd_resume_profile') || '{}'));
    });
  }

  async function sbSignOut() {
    try {
      await fetch(SUPABASE_URL + '/auth/v1/logout', {
        method: 'POST',
        headers: sbHeaders(),
      });
    } catch(e) { /* best-effort logout */ }
  }

  async function dbLoadApps() {
    const PAGE_SIZE = 1000;
    let allRows = [];
    let offset  = 0;
    // Paginate to bypass Supabase's default 1000-row cap
    while (true) {
      const res = await sbFetch(
        SUPABASE_URL + `/rest/v1/applications?username=eq.${currentUser.id}&select=*&order=created_at.asc&limit=${PAGE_SIZE}&offset=${offset}`,
        { headers: { ...sbHeaders(), 'Range-Unit': 'items', 'Range': `${offset}-${offset + PAGE_SIZE - 1}` } }
      );
      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) break;
      allRows = allRows.concat(data);
      if (data.length < PAGE_SIZE) break;
      offset += PAGE_SIZE;
    }
    return allRows.map(r => ({
      id:       r.id,
      company:  r.company,
      jobTitle: r.job_title,
      url:      r.url,
      jd:       r.jd,
      resume:   r.resume,
      status:   r.status,
      date:     r.date,
      dateRaw:  r.date_raw,
      dateKey:  r.date_key,
      notes:       r.notes,
      followUpDate: r.follow_up_date || '',
    }));
  }

  async function dbSaveApp(app) {
    if (!navigator.onLine) {
      enqueueApp(app);
      applications.push(app);
      renderTable();
      return true; // treat as success so UI updates
    }
    if (!currentUser || !currentUser.id) {
      showToast('Please sign in to save applications', true);
      return false;
    }
    const body = {
      id:        app.id,
      username:  currentUser.id,
      company:   app.company,
      job_title: app.jobTitle,
      url:       app.url,
      jd:        app.jd,
      resume:    app.resume || '',
      status:    app.status,
      date:      app.date,
      date_raw:  app.dateRaw,
      date_key:  app.dateKey,
      notes:          app.notes || '',
      follow_up_date: app.followUpDate || null,
    };
    try {
      const res = await sbFetch(SUPABASE_URL + '/rest/v1/applications', {
        method: 'POST',
        headers: { ...sbHeaders(), 'Prefer': 'return=representation' },
        body: JSON.stringify(body),
      });
      return res.ok;
    } catch(e) {
      showToast('Save failed: ' + (e.message || 'unknown error'), true);
      return false;
    }
  }

  async function dbUpdateApp(app) {
    if (!navigator.onLine) { showToast('No internet — change will sync when online', true); return false; }
    const body = {
      company:   app.company,
      job_title: app.jobTitle,
      url:       app.url,
      jd:        app.jd,
      resume:          app.resume || '',
      status:          app.status,
      notes:           app.notes || '',
      follow_up_date:  app.followUpDate || null,
    };
    try {
      const res = await sbFetch(SUPABASE_URL + '/rest/v1/applications?id=eq.' + app.id, {
        method: 'PATCH',
        headers: { ...sbHeaders(), 'Prefer': 'return=representation' },
        body: JSON.stringify(body),
      });
      return res.ok;
    } catch(e) {
      showToast('Update failed: ' + (e.message || 'unknown error'), true);
      return false;
    }
  }

  async function dbDeleteApp(id) {
    try {
      const res = await sbFetch(SUPABASE_URL + '/rest/v1/applications?id=eq.' + id, {
        method: 'DELETE',
        headers: sbHeaders(),
      });
      return res.ok;
    } catch(e) {
      showToast('Delete failed: ' + (e.message || 'unknown error'), true);
      return false;
    }
  }



  function saveSession(token, user, refreshToken) {
    const s = chromeStore();
    if (s) s.set({ rjd_session: { token, user, refreshToken: refreshToken||'' } }, () => { if (chrome.runtime.lastError) return; });
  }

  function clearSession() {
    const s = chromeStore();
    if (s) s.remove('rjd_session', () => { if (chrome.runtime.lastError) return; });
  }

  function loadSession(cb) {
    const s = chromeStore();
    if (s) {
      s.get('rjd_session', r => {
        if (chrome.runtime.lastError) return cb(null);
        const sess = r.rjd_session || null;
        if (sess) sessionRefreshToken = sess.refreshToken || sess.refresh_token || '';
        cb(sess);
      });
    } else {
      cb(null);
    }
  }

  // ── GEMINI KEY STORAGE ──
  function saveGeminiKey(key, cb) {
    const s = chromeStore();
    if (s) s.set({ rjd_gemini_key: key }, () => { 
      if (chrome.runtime.lastError) return;
      if (cb) cb(); 
    });
  }

  function saveGeminiModel(model, cb) {
    const s = chromeStore();
    if (s) s.set({ rjd_gemini_model: model }, () => { 
      if (chrome.runtime.lastError) return;
      if (cb) cb(); 
    });
  }

  function loadGeminiModel(cb) {
    if (typeof cb !== 'function') return;
    const s = chromeStore();
    if (s) {
      s.get('rjd_gemini_model', r => {
        if (chrome.runtime.lastError) return cb('gemini-1.5-flash');
        cb(r.rjd_gemini_model || 'gemini-1.5-flash');
      });
    } else {
      cb('gemini-1.5-flash');
    }
  }

  function loadGeminiKey(cb) {
    if (typeof cb !== 'function') return;
    const s = chromeStore();
    if (s) {
      s.get('rjd_gemini_key', r => {
        if (chrome.runtime.lastError) return cb('');
        cb(r.rjd_gemini_key || '');
      });
    } else {
      cb('');
    }
  }

  // ── LOADING SCREEN ──
  function showLoading(msg) {
    const main = document.getElementById('rjd-sidebar-content');
    if (!main) return;
    main.innerHTML = `
      <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:40px 20px;">
        <div id="rjd-spinner" style="width:36px;height:36px;border:3px solid #eef2ff;border-top-color:#4f46e5;border-radius:50%;"></div>
        <div style="font-size:13px;color:var(--text-muted,#94a3b8);text-align:center;">${escHtml(msg || 'Loading...')}</div>
      </div>`;
    const s = document.createElement('style');
    s.id = 'rjd-spinner-style';
    s.textContent = '@keyframes rjd-spin{to{transform:rotate(360deg)}} #rjd-spinner{animation:rjd-spin 0.8s linear infinite;}';
    if (!document.getElementById('rjd-spinner-style')) document.head.appendChild(s);
  }

  // ── UTILS ──
  // workingDate: manually chosen date for this session (YYYY-MM-DD), stored in chrome.storage
  let workingDate = '';

  function getWorkingDateObj() {
    if (workingDate) {
      const [y,m,d] = workingDate.split('-').map(Number);
      return new Date(y, m-1, d);
    }
    return new Date();
  }
  function today() {
    return getWorkingDateObj().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  }
  function todayKey() {
    const d = getWorkingDateObj();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function todayISO() {
    const d = getWorkingDateObj();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function escHtml(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function showToast(msg, isError) {
    const t = document.getElementById('rjd-toast');
    if (!t) return;
    t.textContent = msg;
    t.style.background = isError ? '#dc2626' : '';
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2500);
  }
  function getInitials(name) {
    if (!name) return '?';
    return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2);
  }

  // ── GEMINI EXTRACTION ──

  function extractFromDomain() {
    try {
      const hostname = window.location.hostname;
      // LinkedIn
      if (hostname.includes('linkedin.com')) {
        let company = document.querySelector('.job-details-jobs-unified-top-card__company-name a')?.innerText
                   || document.querySelector('.job-details-jobs-unified-top-card__company-name')?.innerText
                   || document.querySelector('.topcard__org-name-link')?.innerText
                   || document.querySelector('.job-details-top-card__company-url')?.innerText;
        let title = document.querySelector('.job-details-jobs-unified-top-card__job-title h1')?.innerText
                 || document.querySelector('h1.t-24')?.innerText
                 || document.querySelector('.top-card-layout__title')?.innerText
                 || document.querySelector('.topcard__title')?.innerText;
        if (company && title) return { company: company.trim(), jobTitle: title.trim(), source: 'linkedin_dom' };
      }
      // Naukri
      if (hostname.includes('naukri.com')) {
        let company = document.querySelector('.jd-header-comp-name a')?.innerText 
                   || document.querySelector('.job-details .company-name')?.innerText;
        let title = document.querySelector('.jd-header-title')?.innerText 
                 || document.querySelector('h1.title')?.innerText;
        if (company && title) return { company: company.trim(), jobTitle: title.trim(), source: 'naukri_dom' };
      }
      // Indeed
      if (hostname.includes('indeed.com')) {
        let company = document.querySelector('[data-company-name="true"] a')?.innerText 
                   || document.querySelector('[data-company-name="true"]')?.innerText;
        let title = document.querySelector('h1[data-testid="jobsearch-JobInfoHeader-title"]')?.innerText
                 || document.querySelector('.jobsearch-JobInfoHeader-title')?.innerText;
        if (title) title = title.replace(/\s*-\s*job post$/i, '');
        if (company && title) return { company: company.trim(), jobTitle: title.trim(), source: 'indeed_dom' };
      }
      // Glassdoor
      if (hostname.includes('glassdoor.')) {
        let company = document.querySelector('[data-test="employerName"]')?.innerText?.split('\n')[0];
        let title = document.querySelector('[data-test="jobTitle"]')?.innerText;
        if (company && title) return { company: company.replace(/★.*/,'').trim(), jobTitle: title.trim(), source: 'glassdoor_dom' };
      }
      // Wellfound / AngelList
      if (hostname.includes('wellfound.com') || hostname.includes('angel.co')) {
        let company = document.querySelector('h2.styles_name__mkZaj')?.innerText
                   || document.querySelector('h1.styles_component__2q82k')?.innerText; // Depends on view
        let title = document.querySelector('h2.styles_title__D_wGE')?.innerText
                 || document.querySelector('.styles_jobTitle__...')?.innerText; // Adjust if found
        if (company) return { company: company.trim(), jobTitle: title?.trim(), source: 'wellfound_dom' };
      }
      // Internshala
      if (hostname.includes('internshala.com')) {
        let company = document.querySelector('.company_name a')?.innerText || document.querySelector('.company_name')?.innerText;
        let title = document.querySelector('.profile_on_detail_page')?.innerText;
        if (company && title) return { company: company.trim(), jobTitle: title.trim(), source: 'internshala_dom' };
      }
      // Greenhouse
      if (hostname.includes('greenhouse.io')) {
        let company = document.querySelector('.company-name')?.innerText
                   || document.querySelector('.app-title')?.innerText?.split('at')?.[1];
        let title = document.querySelector('.app-title')?.innerText?.split('at')?.[0]
                 || document.querySelector('h1.entry-title')?.innerText;
        if (company || title) return { company: company?.trim(), jobTitle: title?.trim(), source: 'greenhouse_dom' };
      }
      // Lever
      if (hostname.includes('lever.co')) {
        let title = document.querySelector('.posting-headline h2')?.innerText;
        let company = document.querySelector('meta[property="og:site_name"]')?.content 
                   || document.title.split('-')?.[1];
        if (company || title) return { company: company?.trim(), jobTitle: title?.trim(), source: 'lever_dom' };
      }
      // Workday
      if (hostname.includes('myworkdayjobs.com')) {
        let title = document.querySelector('[data-automation-id="jobTitle"]')?.innerText 
                 || document.querySelector('h1')?.innerText;
        let company = document.querySelector('[data-automation-id="companyLogo"]')?.alt
                   || document.querySelector('[data-automation-id="companyLogo"]')?.getAttribute('aria-label')
                   || document.title.split('-')?.[0]?.trim();
        if (company || title) return { company: company?.trim(), jobTitle: title?.trim(), source: 'workday_dom' };
      }
    } catch(e) { console.warn('[AI Blaze] DOM extraction error:', e.message); }
    return null;
  }

  function findJobPostingLD(obj) {
    if (!obj || typeof obj !== 'object') return null;
    if (obj['@type'] === 'JobPosting' || (Array.isArray(obj['@type']) && obj['@type'].includes('JobPosting'))) return obj;
    if (Array.isArray(obj)) {
      for (let item of obj) {
        const found = findJobPostingLD(item);
        if (found) return found;
      }
    } else {
      for (let key in obj) {
        if (typeof obj[key] === 'object') {
          const found = findJobPostingLD(obj[key]);
          if (found) return found;
        }
      }
    }
    return null;
  }

  // Fallback 1: scrape visible page DOM for company/title signals
  function scrapePageSignals() {
    const signals = {};

    // --- Precise Domain Extraction (Golden Path) ---
    const domainSignals = extractFromDomain();
    if (domainSignals) {
      signals.company = domainSignals.company;
      signals.jobTitle = domainSignals.jobTitle;
      signals.preciseDomain = true;
    }

    // --- Job Title Common Fallbacks ---
    const ogTitle = document.querySelector('meta[property="og:title"]')?.content || '';
    const metaTitle = document.querySelector('meta[name="title"]')?.content || '';
    const h1 = document.querySelector('h1')?.innerText?.trim() || '';
    const pageTitle = document.title || '';
    signals.rawTitle = ogTitle || metaTitle || h1 || pageTitle;

    // --- Structured Data (Silver Path) ---
    if (!signals.company || !signals.jobTitle) {
      try {
        const jsonLds = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
        for (const el of jsonLds) {
          const obj = JSON.parse(el.textContent);
          const jobNode = findJobPostingLD(obj);
          if (jobNode) {
            let cName = typeof jobNode.hiringOrganization === 'string' ? jobNode.hiringOrganization : jobNode.hiringOrganization?.name;
            if (cName && !signals.company) signals.company = cName;
            if (jobNode.title && !signals.jobTitle) signals.jobTitle = jobNode.title;
          }
        }
      } catch(e) {}
    }

    // Try og:site_name as company hint
    if (!signals.company) {
      signals.ogSiteName = document.querySelector('meta[property="og:site_name"]')?.content || '';
    }

    // Collect visible text near common company-label elements
    const companySelectors = [
      '[data-company-name]','[class*="company-name"]','[class*="companyName"]',
      '[class*="employer"]','[class*="org-name"]','[itemprop="name"]',
      '[class*="hiring-company"]','[class*="job-company"]',
    ];
    for (const sel of companySelectors) {
      const el = document.querySelector(sel);
      if (el?.innerText?.trim()) { signals.domCompany = el.innerText.trim(); break; }
    }

    // Logo Scraper: Check alt text of the first link containing a logo/brand
    if (!signals.domCompany) {
      const logoLink = document.querySelector('header a, nav a, .navbar a, [class*="logo"] a');
      if (logoLink) {
        const logoImg = logoLink.querySelector('img, svg');
        const label = logoLink.getAttribute('aria-label') || logoImg?.getAttribute('alt') || logoImg?.getAttribute('aria-label');
        if (label && !/logo|home|brand/i.test(label.trim())) {
          signals.domCompany = label.trim();
        }
      }
    }

    // URL hostname and path as deep company hints
    try {
      const url = new URL(window.location.href);
      const host = url.hostname.toLowerCase();
      const path = url.pathname.toLowerCase();
      
      const GENERIC_SUBDOMAINS = /^(www|jobs|careers|apply|boards|app|recruit|hire|join|talent|work|portal|listing|career|job|opportunity|opportunities)$/;

      // Handle subdomains (acme.lever.co -> acme, acme.com -> acme)
      const parts = host.replace(/^www\./, '').split('.');
      let candidate = parts[0];

      // If subdomain is generic, use the domain name instead
      if (GENERIC_SUBDOMAINS.test(candidate) && parts.length >= 2) {
        candidate = parts[1];
      }

      // Special handling for major portals where path is often better
      if (host.includes('lever.co') || host.includes('greenhouse.io') || host.includes('workdayjobs.com') || host.includes('simplify.jobs')) {
         const pathSegments = path.split('/').filter(Boolean);
         // Check if first or second segment might be the company
         // (e.g. /p/acme, /company/acme, /acme/jobs)
         if (pathSegments.length > 0) {
            let segment = pathSegments[0];
            if (/^(p|company|at|jobs|hiring|listing)$/.test(segment) && pathSegments.length > 1) {
              segment = pathSegments[1];
            }
            candidate = segment;
         }
      }

      if (candidate && !GENERIC_SUBDOMAINS.test(candidate)) {
        signals.hostname = candidate.replace(/[\-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
      }
    } catch(e) {}

    return signals;
  }

  // ── JD TEXT PRE-PARSER ──
  // Extracts company/title directly from the copied JD text using regex patterns.
  // This is the MOST reliable source when the user is on a different page.
  function parseJdTextSignals(jdText) {
    if (!jdText || !jdText.trim()) return {};
    const signals = {};
    const lines = jdText.split('\n').map(l => l.trim()).filter(Boolean);

    // Pattern 1: Labelled fields — "Company: Acme Corp", "Role: Software Engineer"
    const COMPANY_LABELS = /^(?:company|employer|organisation|organization|hiring company|posted by|about the company)\s*[:\-–]\s*(.+)$/i;
    const TITLE_LABELS   = /^(?:job title|role|position|designation|opening|vacancy|job opening|job role)\s*[:\-–]\s*(.+)$/i;
    for (const line of lines) {
      if (!signals.company) {
        const m = line.match(COMPANY_LABELS);
        if (m) signals.company = m[1].trim();
      }
      if (!signals.jobTitle) {
        const m = line.match(TITLE_LABELS);
        if (m) signals.jobTitle = m[1].trim();
      }
      if (signals.company && signals.jobTitle) break;
    }

    // Pattern 2: Top lines sometimes are: "CompanyName\nJobTitle" or vice versa
    // Heuristic: first non-empty line that looks like a proper title (2–6 words, title-case)
    if (!signals.jobTitle) {
      const JOB_TITLE_PATTERN = /^[A-Z][a-z]+(?:\s+[A-Za-z\-\/]+){1,6}$/;
      const SENIOR_WORDS = /\b(senior|junior|lead|staff|principal|associate|intern|manager|engineer|analyst|developer|designer|specialist|consultant|architect|director)\b/i;
      for (const line of lines.slice(0, 8)) {
        if (line.length > 5 && line.length < 80 && SENIOR_WORDS.test(line)) {
          signals.jobTitle = line;
          break;
        }
      }
    }

    // Pattern 3: "at CompanyName" in title  — e.g. "Senior Engineer at Google"
    if (!signals.company && signals.jobTitle) {
      const atMatch = signals.jobTitle.match(/\bat\s+(.+)$/i);
      if (atMatch) {
        signals.company = atMatch[1].trim();
        signals.jobTitle = signals.jobTitle.replace(/\bat\s+.+$/i, '').trim();
      }
    }

    // Pattern 4: Look for "About <Company>" or "About Us" section header
    if (!signals.company) {
      for (const line of lines) {
        const m = line.match(/^About\s+(?!us|the role|this role|this position)(.{2,50})$/i);
        if (m) { signals.company = m[1].replace(/[:\-–].*/, '').trim(); break; }
      }
    }

    // Pattern 5: "We are <Company>" / "At <Company>..." / "Welcome to <Company>"
    if (!signals.company) {
      for (const line of lines.slice(0, 40)) {
        let m = line.match(/^(?:we are|we're|welcome to|join|at|about)\s+([A-Z][A-Za-z0-9&' ]{1,40})[,!.]/i);
        if (!m) m = line.match(/^([A-Z][A-Za-z0-9&' ]{1,40?})\s+is\s+(?:looking|hiring|seeking|a\s+leading|a\s+global)/i);
        if (m) { 
          const candidate = m[1].trim().replace(/\s*(at|@).*/i, '');
          if (candidate.length > 2 && !/^(the|this|our|we|join)$/i.test(candidate)) {
            signals.company = candidate; break; 
          }
        }
      }
    }

    // Pattern 6: Copyright footer or "All rights reserved"
    if (!signals.company) {
      for (const line of lines.slice(-20)) {
        const m = line.match(/\(c\)|©|Copyright\s+(?:\d{4}\s+)?(?:by\s+)?([A-Z][A-Za-z0-9&' ]{2,50?})(?:,?\s+|\.)/i);
        if (m && !/^(all rights reserved|inc|llc|inc\.|llc\.)$/i.test(m[1].trim())) {
          signals.company = m[1].replace(/,?\s+(inc|llc|corp|ltd).*/i, '').trim();
          break;
        }
      }
    }

    return signals;
  }

  // Build the richest possible context string to send to Gemini
  function buildExtractionContext(jdText, pageUrl) {
    const parts = [];
    const hasJD = jdText && typeof jdText === 'string' && jdText.trim().length > 50;

    try {
      // ── PRIORITY 1: JD text pre-parsed signals (most reliable when on a different page) ──
      if (hasJD) {
        const jdSig = parseJdTextSignals(jdText) || {};
        if (jdSig.company)   parts.push(`[JD TEXT company hint] ${jdSig.company}`);
        if (jdSig.jobTitle)  parts.push(`[JD TEXT title hint] ${jdSig.jobTitle}`);
      }

      // ── PRIORITY 2: Page structured/DOM signals (only useful if on the actual job page) ──
      const sig = scrapePageSignals() || {};
      if (sig.preciseDomain) {
        parts.push(`[VERIFIED DOM COMPANY] ${sig.company}`);
        parts.push(`[VERIFIED DOM TITLE] ${sig.jobTitle}`);
      } else {
        if (sig.company)    parts.push(`[PAGE structured data company] ${sig.company}`);
        if (sig.jobTitle)   parts.push(`[PAGE structured data title] ${sig.jobTitle}`);
        if (sig.rawTitle)   parts.push(`[PAGE title/H1] ${sig.rawTitle}`);
        if (sig.ogSiteName) parts.push(`[PAGE og:site_name] ${sig.ogSiteName}`);
        if (sig.domCompany) parts.push(`[PAGE DOM company element] ${sig.domCompany}`);
        if (sig.hostname)   parts.push(`[PAGE hostname hint] ${sig.hostname}`);
      }
    } catch(e) {
      console.warn('[AI Blaze] Context scraping error:', e.message);
    }

    parts.push(`[PAGE URL] ${pageUrl}`);

    // ── PRIORITY 3: Full JD text (let Gemini read it directly) ──
    if (hasJD) {
      parts.push(`[JOB DESCRIPTION TEXT]\n${jdText.substring(0, 8000)}`);
    }

    return parts.join('\n');
  }

  async function extractWithGemini(jdText, pageUrl) {
    const key = await new Promise(res => loadGeminiKey(res));
    if (!key) throw new Error('Gemini API key not set — open Settings to add it');


    const context = buildExtractionContext(jdText, pageUrl);
    const hasJD   = jdText && jdText.trim().length > 50;

    const prompt = `You are a job posting data extractor.

Extract the company name and job title from the context below.

RULES:
- Output ONLY a single raw JSON object. No markdown, no code fences, no explanation.
- Format: {"company_name":"...","job_title":"..."}
- company_name: the actual HIRING COMPANY — never a job board (LinkedIn, Indeed, Naukri, Glassdoor, Internshala, Wellfound, Simplify, Monster). USE the [PAGE URL] or [PAGE hostname hint] to identify the hiring organization if it is not clearly listed in the text.
- job_title: the exact role title
- If a value cannot be determined, use ""

CONTEXT:
${context}`;

    const res = await callGeminiBlaze(key, prompt);
    let raw = (res || '').trim();

    // Strip markdown fences if Gemini wraps with ```json ... ```
    raw = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();

    let parsed = { company_name: '', job_title: '' };
    try {
      parsed = JSON.parse(raw);
    } catch(e) {
      // Regex fallback if JSON.parse still fails
      parsed.company_name = raw.match(/"company_name"\s*:\s*"([^"]*)"/)?.[1] || '';
      parsed.job_title    = raw.match(/"job_title"\s*:\s*"([^"]*)"/)?.[1]    || '';
    }

    // Normalize: ensure company_name and job_title are always strings
    parsed.company_name = String(parsed.company_name ?? '');
    parsed.job_title    = String(parsed.job_title ?? '');

    // Eligibility is always true now (extraction only — eligibility removed from prompt)
    parsed.isEligible = true;
    parsed.eligibilityReason = '';

    // ── Post-processing fallbacks ──
    try {
    const sig   = scrapePageSignals() || {};
    const jdSig = parseJdTextSignals(jdText) || {};

    // If we have precise domain extraction, trust it over Gemini for company name
    if (sig.preciseDomain && sig.company) {
      if (!parsed.company_name || parsed.company_name !== sig.company) {
        parsed.company_name = sig.company;
      }
    }

    // If Gemini returned a job board as the company, override with signals
    const JOB_BOARDS = /^(linkedin|indeed|glassdoor|naukri|monster|ziprecruiter|dice|simplyhired|hired\.com|wellfound|angel\.co|internshala|simplify|greenhouse|lever|workday|ashby|lever\.co|greenhouse\.io|myworkdayjobs|breezy|ashbyhq)$/i;
    if (!parsed.company_name || JOB_BOARDS.test((parsed.company_name || '').trim())) {
      parsed.company_name = jdSig.company || sig.company || sig.domCompany || sig.ogSiteName || sig.hostname || '';
    }

    // If title is empty, use JD pre-parsed title first, then structured data
    if (!parsed.job_title) {
      parsed.job_title = jdSig.jobTitle || sig.jobTitle || '';
    }
    // Last resort: parse page title
    if (!parsed.job_title && sig.rawTitle) {
      parsed.job_title = sig.rawTitle
        .replace(/\s*[\|\-–—]\s*(linkedin|indeed|glassdoor|naukri|careers|jobs|internshala).*/i, '')
        .replace(/\s*(at|@)\s+[\w\s]+$/, '')
        .trim()
        .substring(0, 120);
    }

    // Capitalize company name if all-lowercase
    if (parsed.company_name && parsed.company_name === parsed.company_name.toLowerCase()) {
      parsed.company_name = parsed.company_name.replace(/\b\w/g, c => c.toUpperCase());
    }

    // Strip "at CompanyName" from job title if it snuck in
    if (parsed.job_title && parsed.company_name) {
      parsed.job_title = parsed.job_title
        .replace(new RegExp(`\\s*at\\s+${parsed.company_name}\\s*$`, 'i'), '')
        .trim();
    }
    } catch(postErr) {
      console.warn('[AI Blaze] Post-processing error:', postErr.message);
    }

    // Final safety: ensure strings
    parsed.company_name = String(parsed.company_name || '');
    parsed.job_title    = String(parsed.job_title || '');
    parsed.url = pageUrl;
    return parsed;
  }






  /**
   * Universal AI Engines for v2.0 Copilot
   */


  async function fetchWithRetry(url, opts, retries = 3, delay = 2000) {
    for (let i = 0; i < retries; i++) {
      try {
        const resp = await fetch(url, opts);
        if (resp.status === 429) {
          AppLogger.warn(`Gemini Rate Limited (429). Retry ${i + 1}/${retries} in ${delay}ms...`);
          await new Promise(res => setTimeout(res, delay));
          delay *= 2; // Exponential backoff
          continue;
        }
        return resp;
      } catch (e) {
        if (i === retries - 1) throw e;
        await new Promise(res => setTimeout(res, delay));
        delay *= 2;
      }
    }
  }

  async function callGeminiBlaze(key, prompt) {
    const DEFAULT_MODEL = 'gemini-2.0-flash';
    const DEPRECATED = ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-3.1-flash-lite'];
    let model = await new Promise(res => {
      if (typeof chrome !== 'undefined' && chrome.storage?.local) {
        chrome.storage.local.get('rjd_gemini_model', data => res(data.rjd_gemini_model || DEFAULT_MODEL));
      } else {
        res(localStorage.getItem('rjd_gemini_model') || DEFAULT_MODEL);
      }
    });
    // Auto-migrate deprecated models
    if (DEPRECATED.includes(model)) {
      model = DEFAULT_MODEL;
      try { chrome.storage?.local?.set({ rjd_gemini_model: model }); } catch(e) {}
    }

    const endpoints = [
      `https://generativelanguage.googleapis.com/v1/models/${model}:generateContent?key=${key}`,
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`
    ];

    let lastErr = null;
    for (const url of endpoints) {
      try {
        const resp = await fetchWithRetry(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.7, topK: 40, topP: 0.95, maxOutputTokens: 2048 }
          })
        });

        if (resp.ok) {
          const data = await resp.json();
          return String(data.candidates?.[0]?.content?.parts?.[0]?.text ?? '');
        }
        
        const errData = await resp.json();
        lastErr = errData.error?.message || `HTTP ${resp.status}`;
        if (resp.status !== 404 && resp.status !== 400 && resp.status !== 429) break; 
      } catch (e) {
        lastErr = e.message;
      }
    }

    throw new Error(`Gemini Error: ${lastErr} (Model: ${model}). Check your API key or use a different model in Settings.`);
  }

  async function runExtract() {
    const statusEl = document.getElementById('rjd-extract-status');
    if (!statusEl) return;

    const extractBtn = document.getElementById('rjd-extract-btn');
    statusEl.textContent = '⏳ Extracting...';
    if (extractBtn) { extractBtn.disabled = true; extractBtn.style.opacity = '0.7'; extractBtn.textContent = '⏳ Extracting...'; }
    try {
      let clipText = '';
      try { clipText = await navigator.clipboard.readText(); } catch(e) {}
      clipText = clipText || '';

      if (!clipText.trim()) {
        // Fall back to page body text so Gemini always has content to work with
        clipText = document.body.innerText.substring(0, 8000);
        statusEl.textContent = '⚡ No clipboard — using page text...';
      }

      const result = await extractWithGemini(clipText, window.location.href);

      // Always fill URL and JD
      document.getElementById('rjd-new-url').value = result.url || '';
      document.getElementById('rjd-new-jd').value  = clipText;

      // Only fill company/title if eligible
      if (result.isEligible !== false) {
        document.getElementById('rjd-new-company').value = result.company_name || '';
        document.getElementById('rjd-new-title').value   = result.job_title   || '';
      } else {
        document.getElementById('rjd-new-company').value = '';
        document.getElementById('rjd-new-title').value   = '';
      }

      const gotBoth    = result.company_name && result.job_title;
      const gotPartial = result.company_name || result.job_title;
      
      if (!result.isEligible) {
        statusEl.textContent = '✕ Not Eligible: ' + (result.eligibilityReason || 'Exclusion criteria met');
        statusEl.style.color = '#fca5a5';
        statusEl.style.fontWeight = '700';
      } else if (gotBoth) {
        statusEl.textContent = '✓ Eligible & Extracted — review and save';
        statusEl.style.color = '#34d399';
      } else if (gotPartial) {
        statusEl.textContent = '⚠ Partially extracted — fill missing field';
        statusEl.style.color = '#fde68a';
      } else {
        statusEl.textContent = 'Could not extract — fill in manually';
        statusEl.style.color = '#fca5a5';
      }
      
      if (extractBtn) { extractBtn.disabled = false; extractBtn.style.opacity = '1'; extractBtn.innerHTML = '<span style="font-size:16px;">✦</span> Extract from Clipboard + Page URL'; }
      if (result.isEligible) {
        setTimeout(() => { statusEl.textContent = ''; statusEl.style.color = ''; }, 5000);
      }
    } catch(err) {
      statusEl.textContent = '✕ ' + (err.message || 'Extraction failed');
      statusEl.style.color = '#fca5a5';
      if (extractBtn) { extractBtn.disabled = false; extractBtn.style.opacity = '1'; extractBtn.innerHTML = '<span style="font-size:16px;">✦</span> Extract from Clipboard + Page URL'; }
    }
  }

  // ════════════════════════════════════════
  // SETTINGS SCREEN
  // ════════════════════════════════════════
  function renderSettingsScreen(returnTo) {
    const main = document.getElementById('rjd-sidebar-content');
    if (!main) return;

    let activeSection = 'apikey';

    function renderSettings() {
      main.innerHTML = `
        <div style="flex:1;display:flex;flex-direction:column;overflow:hidden;">

          <div style="background:linear-gradient(135deg,#4f46e5,#7c3aed);padding:12px 16px;display:flex;align-items:center;gap:10px;flex-shrink:0;">
            <button id="rjd-settings-back-btn" style="background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.2);color:#fff;border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer;backdrop-filter:blur(8px);font-family:inherit;">← Back</button>
            <span style="font-size:14px;font-weight:700;color:#fff;">Settings</span>
          </div>

          <div style="flex:1;display:flex;overflow:hidden;">

            <!-- NAV -->
            <div style="width:140px;background:var(--bg-secondary,#f8fafc);border-right:1px solid var(--border-color,#e2e8f0);flex-shrink:0;overflow-y:auto;padding:8px 0;">
              <div style="font-size:9px;font-weight:700;color:var(--text-muted,#94a3b8);text-transform:uppercase;letter-spacing:0.8px;padding:8px 14px 4px;">General</div>
              <div class="rjd-settings-nav-item ${activeSection==='apikey'?'rjd-snav-active':''}" data-sec="apikey">🔑 API Key</div>
              <div class="rjd-settings-nav-item ${activeSection==='resumeprofile'?'rjd-snav-active':''}" data-sec="resumeprofile">📄 Resume Profile</div>
              <div style="font-size:9px;font-weight:700;color:var(--text-muted,#94a3b8);text-transform:uppercase;letter-spacing:0.8px;padding:12px 14px 4px;">Info</div>
              <div class="rjd-settings-nav-item ${activeSection==='shortcuts'?'rjd-snav-active':''}" data-sec="shortcuts">⌨️ Shortcuts</div>
              <div class="rjd-settings-nav-item ${activeSection==='privacy'?'rjd-snav-active':''}" data-sec="privacy">🛡️ Privacy</div>
              <div class="rjd-settings-nav-item ${activeSection==='about'?'rjd-snav-active':''}" data-sec="about">ℹ️ About</div>
            </div>

            <!-- CONTENT -->
            <div id="rjd-settings-panel" style="flex:1;overflow-y:auto;padding:18px;"></div>
          </div>
        </div>`;

      // Nav click
      main.querySelectorAll('.rjd-settings-nav-item').forEach(item => {
        item.addEventListener('click', () => {
          activeSection = item.dataset.sec;
          main.querySelectorAll('.rjd-settings-nav-item').forEach(i => i.classList.remove('rjd-snav-active'));
          item.classList.add('rjd-snav-active');
          renderSection(activeSection);
        });
      });

      document.getElementById('rjd-settings-back-btn').addEventListener('click', () => {
        // Warning fix #5: honour the returnTo parameter instead of always going to tracker
        if (returnTo === 'assistant') renderAssistantScreen();
        else renderTrackerScreen();
      });

      renderSection(activeSection);
    }

    function renderSection(sec) {
      const panel = document.getElementById('rjd-settings-panel');
      if (!panel) return;

      if (sec === 'apikey') {
        panel.innerHTML = `
          <div style="font-size:15px;font-weight:700;color:var(--text-primary,#1e293b);margin-bottom:4px;">Gemini API Key</div>
          <div style="font-size:12px;color:var(--text-muted,#94a3b8);margin-bottom:14px;">Powers AI extraction. Free key from Google.</div>
          <div style="background:var(--accent-light,#eef2ff);border:1px solid var(--accent-border,#c7d2fe);border-radius:8px;padding:12px;margin-bottom:16px;font-size:11px;color:var(--accent-primary,#4f46e5);line-height:1.6;">
            Your key is stored only in your browser. It is sent directly to Google Gemini — never to any other server.
          </div>
          <div id="rjd-sk-msg"></div>
          <label style="font-size:10px;font-weight:700;color:var(--text-muted,#94a3b8);text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">API Key</label>
          <input type="password" id="rjd-sk-input" placeholder="AIzaSy..." style="width:100%;padding:10px 12px;border:1.5px solid var(--border-color,#e2e8f0);border-radius:8px;font-size:12px;font-family:inherit;background:var(--bg-primary,#fff) !important;color:var(--text-primary,#1e293b) !important;margin-bottom:10px;"/>
          
          <label style="font-size:10px;font-weight:700;color:var(--text-muted,#94a3b8);text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Model ID</label>
          <input type="text" id="rjd-sm-input" placeholder="gemini-2.0-flash" list="rjd-models-list" style="width:100%;padding:10px 12px;border:1.5px solid var(--border-color,#e2e8f0);border-radius:8px;font-size:12px;font-family:inherit;background:var(--bg-primary,#fff) !important;color:var(--text-primary,#1e293b) !important;margin-bottom:16px;"/>
          <datalist id="rjd-models-list">
            <option value="gemini-1.5-flash">
            <option value="gemini-1.5-pro">
            <option value="gemini-2.0-flash">
            <option value="gemini-2.5-flash-lite">
            <option value="gemini-3.1-flash-lite">
          </datalist>

          <div style="display:flex;gap:8px;margin-bottom:16px;">
            <button id="rjd-sk-show" style="padding:8px 14px;border:1px solid var(--border-color,#e2e8f0);border-radius:8px;font-size:11px;cursor:pointer;background:var(--bg-secondary,#f8fafc);color:var(--text-muted,#94a3b8);font-family:inherit;transition:all 0.2s;">Show</button>
            <button id="rjd-sk-save" class="rjd-primary-btn" style="flex:1;padding:8px;">Save Config</button>
          </div>

          <div style="border-top:1px solid var(--border-light,#f1f5f9); padding-top:14px; margin-bottom:16px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
               <div style="font-size:13px; font-weight:700; color:var(--text-primary);">v2.0 Copilot Beta</div>
               <label class="rjd-switch">
                 <input type="checkbox" id="v2-copilot-toggle">
                 <span class="rjd-slider round"></span>
               </label>
            </div>
            <div style="font-size:11px; color:var(--text-muted); line-height:1.4;">
              Enable Highlight-to-Prompt, Shortcut Triggers (-ans, /fix), and Smart Context across all websites.
            </div>
          </div>

          <div style="border-top:1px solid var(--border-light,#f1f5f9);padding-top:14px;">
            <div style="font-size:12px;font-weight:600;color:var(--text-primary,#1e293b);margin-bottom:8px;">How to get a free Gemini key:</div>
            <div style="font-size:12px;color:var(--text-secondary,#475569);line-height:1.8;">
              1. Go to <strong>aistudio.google.com</strong><br>
              2. Click <strong>Get API Key → Create API key</strong><br>
              3. Copy and paste it above
            </div>
          </div>`;

        loadGeminiKey(k => { if (k) document.getElementById('rjd-sk-input').value = k; });
        loadGeminiModel(m => { if (m) document.getElementById('rjd-sm-input').value = m; });

        setTimeout(() => {
          // v2 Copilot Toggle Logic
          const v2Toggle = document.getElementById('v2-copilot-toggle');
          const isV2Enabled = localStorage.getItem('rjd_v2_enabled') === 'true';
          if (v2Toggle) {
            v2Toggle.checked = isV2Enabled;
            v2Toggle.onchange = () => {
              localStorage.setItem('rjd_v2_enabled', v2Toggle.checked);
              if (typeof chrome !== 'undefined' && chrome.storage?.local) {
                chrome.storage.local.set({ rjd_v2_enabled: v2Toggle.checked });
              }
              showToast('Copilot ' + (v2Toggle.checked ? 'Enabled' : 'Disabled') + ' — Refresh page to apply');
            };
          }
        }, 0);

        let shown = false;
        document.getElementById('rjd-sk-show').addEventListener('click', () => {
          shown = !shown;
          document.getElementById('rjd-sk-input').type = shown ? 'text' : 'password';
          document.getElementById('rjd-sk-show').textContent = shown ? 'Hide' : 'Show';
        });

        document.getElementById('rjd-sk-save').addEventListener('click', () => {
          const key = document.getElementById('rjd-sk-input').value.trim();
          const model = document.getElementById('rjd-sm-input').value.trim();
          
          if (!key) { showSMsg('Enter your API key', true); return; }
          if (!key.startsWith('AIza')) { showSMsg('Key should start with AIza...', true); return; }
          
          saveGeminiKey(key, () => {
            GEMINI_KEY = key;
            if (model) {
              saveGeminiModel(model, () => {
                showSMsg('Config saved ✓', false);
              });
            } else {
              showSMsg('Key saved ✓', false);
            }
          });
        });


      } else if (sec === 'resumeprofile') {
        panel.innerHTML = `<div style="display:flex;justify-content:center;padding:40px;"><div class="rjd-loader"></div></div>`;
        
        loadResumeProfileDB().then(p => {
          const customSections = p.custom_sections || [];
          
          const renderProfileForm = () => {
            const renderSectionsSidebarHTML = () => {
              return customSections.map((s, idx) => `
                <div class="rjd-custom-sec-item" data-idx="${idx}" style="background:var(--bg-secondary,#f8fafc);padding:10px;border-radius:8px;margin-bottom:12px;border:1px solid var(--border-color,#e2e8f0);">
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                    <input type="text" class="rp-custom-title" value="${escHtml(s.title)}" placeholder="Section Title" style="font-weight:700;border:none;background:transparent;padding:0;font-size:11px;color:var(--text-primary);width:70%;"/>
                    <button class="rjd-remove-sec-btn" data-idx="${idx}" style="background:none;border:none;color:#e53e3e;font-size:10px;cursor:pointer;padding:0;">Remove</button>
                  </div>
                  <textarea class="rp-custom-content" rows="2" placeholder="Content..." style="width:100%;padding:4px;font-size:10px;background:var(--bg-primary);border:1px solid var(--border-color);border-radius:4px;resize:none;">${escHtml(s.content)}</textarea>
                </div>
              `).join('');
            };

            panel.innerHTML = `
              <div style="font-size:15px;font-weight:700;color:var(--text-primary,#1e293b);margin-bottom:4px;">Resume Personal Profile</div>
              <div style="font-size:12px;color:var(--text-muted,#94a3b8);margin-bottom:14px;">These details are cloud-synced across devices. ✓</div>
              <div id="rjd-rp-msg"></div>
              
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
                <div><label style="font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">Full Name</label><input type="text" id="rp-name" class="rjd-sidebar-input" value="${escHtml(p.name||'')}" style="width:100%;padding:6px;font-size:11px;"/></div>
                <div><label style="font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">Title</label><input type="text" id="rp-title" class="rjd-sidebar-input" value="${escHtml(p.title||'')}" style="width:100%;padding:6px;font-size:11px;"/></div>
                <div><label style="font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">Email</label><input type="email" id="rp-email" class="rjd-sidebar-input" value="${escHtml(p.email||'')}" style="width:100%;padding:6px;font-size:11px;"/></div>
                <div><label style="font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">Phone</label><input type="text" id="rp-phone" class="rjd-sidebar-input" value="${escHtml(p.phone||'')}" style="width:100%;padding:6px;font-size:11px;"/></div>
                <div><label style="font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">Location</label><input type="text" id="rp-location" class="rjd-sidebar-input" value="${escHtml(p.location||'')}" style="width:100%;padding:6px;font-size:11px;"/></div>
                <div><label style="font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">LinkedIn</label><input type="text" id="rp-linkedin" class="rjd-sidebar-input" value="${escHtml(p.linkedin||'')}" style="width:100%;padding:6px;font-size:11px;"/></div>
              </div>

              <div style="margin-bottom:12px;">
                <label style="font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">🎓 Education (Degree | Year | Uni | Country)</label>
                <textarea id="rp-education" class="rjd-sidebar-input" rows="2" style="width:100%;padding:6px;font-size:11px;resize:none;">${escHtml(p.education||'')}</textarea>
              </div>

              <div style="margin-bottom:12px;">
                <label style="font-size:9px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">📜 Certifications (one per line)</label>
                <textarea id="rp-certs" class="rjd-sidebar-input" rows="2" style="width:100%;padding:6px;font-size:11px;resize:none;">${escHtml(p.certs||'')}</textarea>
              </div>

              <div id="rp-custom-sections-container">
                ${renderSectionsSidebarHTML()}
              </div>

              <div style="margin-bottom:16px;">
                <button id="rp-add-section-btn" style="width:100%;padding:8px;border:1px dashed var(--border-color);background:none;color:var(--text-muted);font-size:11px;border-radius:8px;cursor:pointer;">+ Add Section (e.g. Projects)</button>
              </div>

              <button id="rjd-rp-save" class="rjd-primary-btn" style="width:100%;padding:10px;font-weight:700;">Save Personal Profile</button>
            `;

            // Add Section logic
            document.getElementById('rp-add-section-btn').addEventListener('click', () => {
              customSections.push({ title: '', content: '' });
              document.getElementById('rp-custom-sections-container').innerHTML = renderSectionsSidebarHTML();
              attachSidebarSecListeners();
            });

            const attachSidebarSecListeners = () => {
              document.querySelectorAll('.rjd-remove-sec-btn').forEach(btn => {
                btn.onclick = () => {
                  customSections.splice(parseInt(btn.dataset.idx), 1);
                  document.getElementById('rp-custom-sections-container').innerHTML = renderSectionsSidebarHTML();
                  attachSidebarSecListeners();
                };
              });
            };
            attachSidebarSecListeners();

            document.getElementById('rjd-rp-save').addEventListener('click', async () => {
              const btn = document.getElementById('rjd-rp-save');
              btn.disabled = true; btn.textContent = 'Saving...';

              // Capture custom sections
              const updatedCustom = [];
              document.querySelectorAll('.rjd-custom-sec-item').forEach(item => {
                const t = item.querySelector('.rp-custom-title').value.trim();
                const c = item.querySelector('.rp-custom-content').value.trim();
                if (t) updatedCustom.push({ title: t, content: c });
              });

              const profile = {
                name: document.getElementById('rp-name').value.trim(),
                title: document.getElementById('rp-title').value.trim(),
                email: document.getElementById('rp-email').value.trim(),
                phone: document.getElementById('rp-phone').value.trim(),
                location: document.getElementById('rp-location').value.trim(),
                linkedin: document.getElementById('rp-linkedin').value.trim(),
                education: document.getElementById('rp-education').value.trim(),
                certs: document.getElementById('rp-certs').value.trim(),
                custom_sections: updatedCustom
              };

              const ok = await saveResumeProfileDB(profile);
              btn.disabled = false; btn.textContent = 'Save Personal Profile';
              
              const msg = document.getElementById('rjd-rp-msg');
              if (ok) {
                msg.innerHTML = `<div style="padding:7px;background:#f0fff4;color:#276749;border:1px solid #c6f6d5;border-radius:6px;font-size:11px;margin-bottom:10px;text-align:center;">Profile saved and synced ✓</div>`;
              } else {
                msg.innerHTML = `<div style="padding:7px;background:#fff5f5;color:#c53030;border:1px solid #feb2b2;border-radius:6px;font-size:11px;margin-bottom:10px;text-align:center;">Save failed (Cloud)</div>`;
              }
              setTimeout(() => { if (msg) msg.innerHTML = ''; }, 3000);
            });
          };

          renderProfileForm();
        });

      } else if (sec === 'shortcuts') {
        panel.innerHTML = `
          <div style="font-size:14px;font-weight:700;color:#1F4E79;margin-bottom:3px;">Keyboard Shortcuts</div>
          <div style="font-size:11px;color:#718096;margin-bottom:14px;">Speed up your workflow with these shortcuts.</div>
          <div style="display:flex;flex-direction:column;gap:4px;">
            ${[
              ['Open / close sidebar',  'Alt + Shift + T'],
              ['Extract & Save',        'Alt + Shift + E'],
              ['New application',       'Alt + Shift + N'],
              ['Open settings',         'Alt + Shift + S'],
              ['Close panel / back',    'Escape'],
            ].map(([action, key]) =>
              '<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-radius:7px;background:#f8fafc;border:1px solid #e2e8f0;">'
              + '<span style="font-size:12px;color:#1a202c;">' + action + '</span>'
              + '<kbd style="background:#fff;border:1px solid #cbd5e0;border-bottom:2px solid #cbd5e0;border-radius:5px;padding:3px 8px;font-size:10px;font-family:monospace;color:#1F4E79;font-weight:700;">' + key + '</kbd>'
              + '</div>'
            ).join('')}
          </div>
          <div style="margin-top:12px;background:#ebf4ff;border-radius:7px;padding:10px;font-size:10px;color:#2E75B6;line-height:1.6;">
            Shortcuts work on any page where the extension is active.
          </div>`;

      } else if (sec === 'privacy') {
        panel.innerHTML = `
          <div style="font-size:14px;font-weight:700;color:#1F4E79;margin-bottom:3px;">Privacy</div>
          <div style="font-size:11px;color:#718096;margin-bottom:14px;">What data we collect and how it's used.</div>
          <div style="display:flex;flex-direction:column;gap:10px;font-size:11px;color:#4a5568;line-height:1.7;">
            <div style="background:#f0fff4;border:1px solid #c6f6d5;border-radius:7px;padding:10px;">
              <strong style="color:#276749;">✓ What we store in Supabase:</strong><br>
              Your email, name, and job applications (company, title, URL, JD, resume, status, notes).
            </div>
            <div style="background:#ebf4ff;border:1px solid #bee3f8;border-radius:7px;padding:10px;">
              <strong style="color:#2E75B6;">✓ Your Gemini API key:</strong><br>
              Stored only in your browser's local storage. Never sent to our servers.
            </div>
            <div style="background:#f0fff4;border:1px solid #c6f6d5;border-radius:7px;padding:10px;">
              <strong style="color:#276749;">✓ No tracking:</strong><br>
              We do not collect analytics, usage data, or any personal information beyond what you enter.
            </div>
            <div style="background:#fff8f0;border:1px solid #fbd38d;border-radius:7px;padding:10px;">
              <strong style="color:#975a16;">⚠ Third parties:</strong><br>
              Job descriptions are sent to Google Gemini API for extraction. Supabase stores your application data. Both have their own privacy policies.
            </div>
          </div>`;

      } else if (sec === 'about') {
        const isDark = document.getElementById('rjd-sidebar').getAttribute('data-theme') === 'dark';
        panel.innerHTML = `
          <div style="font-size:14px;font-weight:700;color:#1F4E79;margin-bottom:3px;">About</div>
          <div style="font-size:11px;color:#718096;margin-bottom:14px;">Version info and credits.</div>
          <div style="margin-bottom:14px;padding:12px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0;">
            <div style="font-size:11px;font-weight:700;color:#1a202c;margin-bottom:8px;">Appearance</div>
            <div style="display:flex;gap:8px;">
              <button data-theme="light" style="flex:1;padding:7px;border-radius:6px;border:2px solid ${isDark?'#e2e8f0':'#1F4E79'};background:${isDark?'#f8fafc':'#ebf4ff'};color:${isDark?'#718096':'#1F4E79'};font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;">☀️ Light</button>
              <button data-theme="dark" style="flex:1;padding:7px;border-radius:6px;border:2px solid ${isDark?'#1F4E79':'#e2e8f0'};background:${isDark?'#1a202c':'#f8fafc'};color:${isDark?'#e2e8f0':'#718096'};font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;">🌙 Dark</button>
              <button data-theme="auto" style="flex:1;padding:7px;border-radius:6px;border:1px solid #e2e8f0;background:#f8fafc;color:#718096;font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;">🖥 Auto</button>
            </div>
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;">
            <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:12px;">
              <span style="color:#718096;">Version</span><span style="font-weight:600;color:#1a202c;">${typeof chrome!=='undefined'&&chrome.runtime?.getManifest?chrome.runtime.getManifest().version:'5.1.0'}</span>
            </div>
            <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:12px;">
              <span style="color:#718096;">AI Model</span><span style="font-weight:600;color:#1a202c;">Dynamic (Settings)</span>
            </div>
            <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:12px;">
              <span style="color:#718096;">Database</span><span style="font-weight:600;color:#1a202c;">Supabase</span>
            </div>
            <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:12px;">
              <span style="color:#718096;">Manifest</span><span style="font-weight:600;color:#1a202c;">Chrome MV3</span>
            </div>
            <div style="display:flex;justify-content:space-between;padding:8px 0;font-size:12px;">
              <span style="color:#718096;">Storage</span><span style="font-weight:600;color:#1a202c;">Cloud + Local</span>
            </div>
          </div>
          <div style="margin-top:16px;background:#f8fafc;border-radius:8px;padding:12px;font-size:11px;color:#718096;text-align:center;line-height:1.6;">
            Built for job seekers who mean business.<br>
            <span style="color:#1F4E79;font-weight:600;">Free forever.</span>
          </div>`;
        panel.querySelectorAll('[data-theme]').forEach(btn => {
          btn.addEventListener('click', () => {
            const t = btn.dataset.theme;
            if (t === 'auto') {
              const dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
              applyTheme(dark ? 'dark' : 'light');
            } else {
              applyTheme(t);
            }
            renderSection('about');
          });
        });
      }

      function showSMsg(msg, isError) {
        const el = document.getElementById('rjd-sk-msg');
        if (!el) return;
        el.innerHTML = `<div style="padding:7px 10px;border-radius:6px;font-size:11px;margin-bottom:10px;background:${isError?'#fff5f5':'#f0fff4'};color:${isError?'#c53030':'#276749'};border:1px solid ${isError?'#fed7d7':'#c6f6d5'};">${escHtml(msg)}</div>`;
      }
    }

    renderSettings();
  }

  

  // ════════════════════════════════════════
  // STATS
  // ════════════════════════════════════════
  function renderStats() {
    const sessionApps = applications.filter(a => a.dateKey === todayKey()).length;
    const thisWeek    = applications.filter(a => { const d = new Date(a.dateRaw); return (new Date()-d) <= 7*86400000; }).length;
    const interviews  = applications.filter(a => a.status === 'Interview Scheduled' || a.status === 'Interview Done').length;
    const offers      = applications.filter(a => a.status === 'Offer').length;
    const el = document.getElementById('rjd-stats');
    if (el) el.innerHTML = `
      <div class="rjd-stat-box"><div class="rjd-stat-num" id="rjd-today-count">${sessionApps}</div><div class="rjd-stat-lbl">This Session</div></div>
      <div class="rjd-stat-box"><div class="rjd-stat-num">${thisWeek}</div><div class="rjd-stat-lbl">This Week</div></div>
      <div class="rjd-stat-box"><div class="rjd-stat-num">${interviews}</div><div class="rjd-stat-lbl">Interviews</div></div>
      <div class="rjd-stat-box"><div class="rjd-stat-num rjd-stat-offer">${offers}</div><div class="rjd-stat-lbl">Offers</div></div>`;
    // Update progress bar
    updateSessionProgress();
  }

  function getSessionTarget() {
    return parseInt(localStorage.getItem('rjd_session_target') || '30', 10);
  }
  function updateSessionProgress() {
    const target     = getSessionTarget();
    const done       = applications.filter(a => a.dateKey === todayKey()).length;
    const pct        = Math.min(100, Math.round((done / target) * 100));
    const progText   = document.getElementById('rjd-session-progress');
    const progBar    = document.getElementById('rjd-progress-bar');
    const targSel    = document.getElementById('rjd-target-select');
    if (progText) progText.textContent = done + '/' + target;
    if (progText) progText.style.color = done >= target ? '#059669' : '';
    if (progBar)  { progBar.style.width = pct + '%'; }
    if (targSel)  targSel.value = String(target);
  }

  // ── TABLE ──
  function updateTrackBadge() {
    const badge = document.getElementById('rjd-toggle-badge');
    if (!badge) return;
    const todayCount = applications.filter(a => a.dateKey === todayKey()).length;
    badge.style.display = todayCount > 0 ? 'flex' : 'none';
    badge.textContent = todayCount > 99 ? '99+' : todayCount;
    // Tooltip so user knows what it means
    const icon = document.getElementById('rjd-toggle-icon');
    if (icon) icon.title = todayCount + ' application' + (todayCount !== 1 ? 's' : '') + ' today';
  }

  function getFiltered() {
    let list = [...applications];
    if (filterStatus !== 'all') list = list.filter(a => a.status === filterStatus);
    if (filterDate) list = list.filter(a => {
      if (!a.dateKey) return false;
      return a.dateKey === filterDate;
    });
    if (filterSearch.trim()) {
      const q = filterSearch.toLowerCase();
      list = list.filter(a => (a.company||'').toLowerCase().includes(q) || (a.jobTitle||'').toLowerCase().includes(q) || (a.url||'').toLowerCase().includes(q));
    }
    return list;
  }

  function renderTable() {
    renderStats();
    updateTrackBadge();
    const filtered = getFiltered();
    const tbody = document.getElementById('rjd-tbody');
    if (!tbody) return;
    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="rjd-empty-row">No applications yet. Click "✦ Extract & Save" to start.</td></tr>`;
      return;
    }
    tbody.innerHTML = filtered.map((app, idx) => {
      const sc = STATUS_COLORS[app.status] || STATUS_COLORS['Applied'];
      const safeUrl = app.url && /^https?:\/\//i.test(app.url) ? app.url : null;
      const addBtn    = `<button class="rjd-add-resume-btn" data-id="${app.id}" title="Paste resume from clipboard" style="padding:4px 8px;border-radius:6px;border:1px solid var(--border-color,#e2e8f0);background:var(--bg-secondary,#f8fafc);color:${app.resume?'#059669':'var(--accent-primary,#4f46e5)'};cursor:pointer;font-size:10px;font-weight:600;font-family:inherit;">${app.resume?'✓ Update':'+ Add'}</button>`;
      const dlBtn     = `<button class="rjd-dl-resume-btn" data-id="${app.id}" title="Download tailored resume" style="padding:4px 8px;border-radius:6px;border:1px solid var(--border-color,#e2e8f0);background:var(--bg-secondary,#f8fafc);color:var(--text-primary,#1e293b);cursor:pointer;font-size:11px;font-family:inherit;${!app.resume?'opacity:0.4;pointer-events:none;':''}">📥</button>`;
      const urlBtn    = safeUrl    ? `<a href="${escHtml(safeUrl)}" target="_blank" rel="noopener noreferrer" class="rjd-url-link">Open</a>` : `<span class="rjd-no-resume">—</span>`;
      const isOverdue = app.followUpDate && app.followUpDate < todayKey().slice(0,10) && app.status !== 'Offer' && app.status !== 'Rejected';
      const followUpBadge = app.followUpDate ? `<div style="font-size:9px;color:${isOverdue?'#dc2626':'#94a3b8'};margin-top:1px;">${isOverdue?'⚠ ':'📅 '}${app.followUpDate}</div>` : '';
      // Status chip (click to cycle)
      const shortStatus = { 'Applied':'Applied','Interview Scheduled':'Interview','Interview Done':'Done','Offer':'Offer','Rejected':'Rejected','Skipped':'Skipped' };
      const statusChip = `<button class="rjd-status-chip-btn" data-id="${app.id}" style="background:${sc.bg};color:${sc.color};border:1.5px solid ${sc.color}33;padding:4px 9px;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;transition:all 0.15s;letter-spacing:0.1px;" title="Click to change status">${shortStatus[app.status]||app.status} ▾</button>`;
      return `<tr class="rjd-row" data-id="${app.id}" style="${isOverdue?'background:#fff5f5 !important;':''}">
        <td class="rjd-td rjd-td-sno">${idx+1}</td>
        <td class="rjd-td rjd-td-company"><div>${escHtml(app.company||'—')}</div>${followUpBadge}</td>
        <td class="rjd-td rjd-td-title">${escHtml(app.jobTitle||'—')}</td>
        <td class="rjd-td rjd-td-url">${urlBtn}</td>
        <td class="rjd-td rjd-td-add">${addBtn}</td>
        <td class="rjd-td rjd-td-dl">${dlBtn}</td>
        <td class="rjd-td rjd-td-date">${escHtml(app.date||'—')}</td>
        <td class="rjd-td rjd-td-status">${statusChip}</td>
      </tr>`;
    }).join('');

    // Event Listeners
    tbody.querySelectorAll('.rjd-status-chip-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const app = applications.find(a => a.id === btn.dataset.id);
        if (!app) return;
        const idx = STATUSES.indexOf(app.status);
        const next = STATUSES[(idx + 1) % STATUSES.length];
        app.status = next;
        await dbUpdateApp(app);
        renderTable();
        showToast('Status → ' + next);
      });
    });

    tbody.querySelectorAll('.rjd-add-resume-btn').forEach(btn => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); saveResumeFromClipboard(btn.dataset.id); });
    });

    tbody.querySelectorAll('.rjd-dl-resume-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const app = applications.find(a=>a.id===btn.dataset.id);
        if (app && app.resume) {
          const old = btn.textContent;
          btn.textContent = '⏳'; btn.disabled = true;
          try {
            await generateIntegratedResume(app);
            showToast('Resume downloaded ✓');
          } catch (err) {
            console.error(err);
            showToast('Download failed: ' + err.message, true);
          } finally {
            btn.textContent = old; btn.disabled = false;
          }
        }
      });
    });

    tbody.querySelectorAll('.rjd-row').forEach(row => {
      row.addEventListener('click', (e) => {
        if (['rjd-status-chip-btn','rjd-add-resume-btn','rjd-dl-resume-btn','rjd-url-link'].some(c=>e.target.classList.contains(c))) return;
        const app = applications.find(a=>a.id===row.dataset.id);
        if (app) showAppDetail(app);
      });
    });
  }

  function showNewAppPanel(autoExtract) {
    const panel = document.getElementById('rjd-new-app-panel');
    const main  = document.getElementById('rjd-main');
    if (panel && main) {
      main.style.display  = 'none';
      panel.style.display = 'flex';
      document.getElementById('rjd-new-company').value = '';
      document.getElementById('rjd-new-title').value   = '';
      document.getElementById('rjd-new-url').value     = '';
      document.getElementById('rjd-new-jd').value      = '';
      document.getElementById('rjd-extract-status').textContent = '';

      // Wire status chips — select "Applied" by default
      const statusInput = document.getElementById('rjd-new-status');
      panel.querySelectorAll('.rjd-status-chip').forEach(chip => {
        if (chip.dataset.val === 'Applied') {
          chip.style.background  = '#eef2ff';
          chip.style.borderColor = '#4f46e5';
          chip.style.color       = '#4f46e5';
        }
        chip.onclick = () => {
          statusInput.value = chip.dataset.val;
          panel.querySelectorAll('.rjd-status-chip').forEach(c => {
            c.style.background  = '#f8fafc';
            c.style.borderColor = '#e2e8f0';
            c.style.color       = '#64748b';
          });
          chip.style.background  = '#eef2ff';
          chip.style.borderColor = '#4f46e5';
          chip.style.color       = '#4f46e5';
        };
      });

      // Input focus glow
      panel.querySelectorAll('input[type=text],input[type=url],textarea').forEach(el => {
        el.onfocus = () => { el.style.borderColor = '#4f46e5'; el.style.boxShadow = '0 0 0 3px rgba(79,70,229,0.12)'; };
        el.onblur  = () => { el.style.borderColor = '#e2e8f0'; el.style.boxShadow = 'none'; };
      });

      // Extract button hover
      const eb = document.getElementById('rjd-extract-btn');
      if (eb) {
        eb.onmouseenter = () => { eb.style.transform = 'translateY(-1px)'; eb.style.boxShadow = '0 6px 20px rgba(79,70,229,0.4)'; };
        eb.onmouseleave = () => { eb.style.transform = ''; eb.style.boxShadow = '0 4px 16px rgba(79,70,229,0.3)'; };
      }

      if (autoExtract) setTimeout(() => runExtract(), 100);
    }
  }


  function hideNewAppPanel() {
    document.getElementById('rjd-new-app-panel').style.display = 'none';
    document.getElementById('rjd-main').style.display = 'flex';
  }

  // ── APP DETAIL ──
  function showAppDetail(app) {
    currentDetailId = app.id;
    const panel = document.getElementById('rjd-detail-panel');
    document.getElementById('rjd-main').style.display  = 'none';
    panel.style.display = 'flex';
    document.getElementById('rjd-detail-company-input').value = app.company  || '';
    document.getElementById('rjd-detail-title-input').value   = app.jobTitle || '';
    // URL — populate editable input and sync Open link
    const urlInput = document.getElementById('rjd-detail-url-input');
    const urlLink  = document.getElementById('rjd-detail-url');
    if (urlInput) urlInput.value = app.url || '';
    function syncDetailUrlLink() {
      const v = urlInput ? urlInput.value.trim() : '';
      if (v) { urlLink.href = v; urlLink.style.opacity = '1'; urlLink.style.pointerEvents = 'auto'; }
      else   { urlLink.href = '#'; urlLink.style.opacity = '0.4'; urlLink.style.pointerEvents = 'none'; }
    }
    syncDetailUrlLink();
    if (urlInput) { urlInput.removeEventListener('input', syncDetailUrlLink); urlInput.addEventListener('input', syncDetailUrlLink); }
    document.getElementById('rjd-detail-date').textContent   = app.date   || '—';
    document.getElementById('rjd-detail-status').textContent = app.status || '—';
    document.getElementById('rjd-detail-jd').textContent     = app.jd     || 'No JD saved.';
    document.getElementById('rjd-detail-notes').value        = app.notes  || '';
    document.getElementById('rjd-detail-followup').value     = app.followUpDate || '';
    const resumeSection = document.getElementById('rjd-detail-resume-section');
    if (app.resume) {
      resumeSection.innerHTML = `
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          <button id="rjd-view-resume-detail" class="rjd-action-btn">View Resume</button>
          <button id="rjd-copy-resume-btn" class="rjd-action-btn rjd-secondary-btn">Copy Resume</button>
          <button id="rjd-update-resume-btn" class="rjd-action-btn rjd-secondary-btn">Update Resume</button>
        </div>`;
      document.getElementById('rjd-view-resume-detail').addEventListener('click', () => showResumeDetail(app));
      document.getElementById('rjd-copy-resume-btn').addEventListener('click', () => {
        navigator.clipboard.writeText(app.resume).then(() => showToast('Resume copied')).catch(() => showToast('Copy failed', true));
      });
      document.getElementById('rjd-update-resume-btn').addEventListener('click',  () => saveResumeFromClipboard(app.id));
    } else {
      resumeSection.innerHTML = `<button id="rjd-add-resume-btn" class="rjd-action-btn">+ Add Resume from Clipboard</button>`;
      document.getElementById('rjd-add-resume-btn').addEventListener('click', () => saveResumeFromClipboard(app.id));
    }
    // Copy JD button
    const copyJdBtn = document.getElementById('rjd-copy-jd-btn');
    if (copyJdBtn) copyJdBtn.addEventListener('click', () => {
      const jd = app.jd || '';
      if (!jd) { showToast('No JD saved', true); return; }
      navigator.clipboard.writeText(jd).then(() => showToast('JD copied')).catch(() => showToast('Copy failed', true));
    });
    // Copy URL button
    const copyUrlBtn = document.getElementById('rjd-copy-url-btn');
    if (copyUrlBtn) copyUrlBtn.addEventListener('click', () => {
      const v = document.getElementById('rjd-detail-url-input')?.value.trim() || '';
      if (!v) { showToast('No URL saved', true); return; }
      navigator.clipboard.writeText(v).then(() => showToast('URL copied')).catch(() => showToast('Copy failed', true));
    });
  }

  function hideAppDetail() {
    document.getElementById('rjd-detail-panel').style.display = 'none';
    document.getElementById('rjd-main').style.display = 'flex';
    currentDetailId = null;
  }

  // ── RESUME DETAIL ──
  function showResumeDetail(app) {
    const panel = document.getElementById('rjd-resume-panel');
    panel.dataset.prev = currentDetailId ? 'detail' : 'main';
    panel.style.display = 'flex';
    document.getElementById('rjd-detail-panel').style.display = 'none';
    document.getElementById('rjd-main').style.display = 'none';
    document.getElementById('rjd-resume-title').textContent = 'Resume — ' + (app.company||'Application');
    document.getElementById('rjd-resume-body').value = app.resume || '';
  }

  function hideResumeDetail() {
    const panel = document.getElementById('rjd-resume-panel');
    panel.style.display = 'none';
    if (panel.dataset.prev === 'detail') {
      const app = applications.find(a=>a.id===currentDetailId);
      if (app) showAppDetail(app);
    } else {
      document.getElementById('rjd-main').style.display = 'flex';
    }
  }

  async function saveResumeFromClipboard(appId) {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) { showToast('Clipboard is empty', true); return; }
      const app = applications.find(a=>a.id===appId);
      if (app) {
        app.resume = text.trim();
        await dbUpdateApp(app);
        showToast('Resume saved');
        renderTable();
        if (currentDetailId === appId) showAppDetail(app);
      }
    } catch { showToast('Could not read clipboard', true); }
  }

  // ── LOGOUT ──
  async function logoutUser() {
    await sbSignOut();
    clearSession();
    // Critical fix #4: reset all state and close sidebar via applySession
    applySession(null);
    const sidebar = document.getElementById('rjd-sidebar');
    if (sidebar) sidebar.classList.remove('open');
  }

  // ════════════════════════════════════════
  // TRACKER SCREEN
  // ════════════════════════════════════════
  function renderTrackerScreen() {
    const main = document.getElementById('rjd-sidebar-content');
    if (!main) return;

    if (!currentUser) return;
    const initials = getInitials(currentUser.name);

    main.innerHTML = `
      <div id="rjd-tracker-wrap">
        <div id="rjd-main" style="display:flex;flex-direction:column;flex:1;overflow:hidden;">
          <div id="rjd-tab-nav" style="display:flex;background:var(--bg-secondary,#f8fafc);border-bottom:1px solid var(--border-color,#e2e8f0);padding:4px 4px 0;">
            <div id="rjd-tab-tracker" class="rjd-tab-item ${currentTab==='tracker'?'active':''}" style="flex:1;text-align:center;padding:10px;font-size:12px;font-weight:700;cursor:pointer;border-bottom:2px solid ${currentTab==='tracker'?'var(--accent-primary,#4f46e5)':'transparent'};color:${currentTab==='tracker'?'var(--accent-primary,#4f46e5)':'var(--text-muted,#94a3b8)'};">📊 Applications</div>
            <div id="rjd-tab-assistant" class="rjd-tab-item ${currentTab==='assistant'?'active':''}" style="flex:1;text-align:center;padding:10px;font-size:12px;font-weight:700;cursor:pointer;border-bottom:2px solid ${currentTab==='assistant'?'var(--accent-primary,#4f46e5)':'transparent'};color:${currentTab==='assistant'?'var(--accent-primary,#4f46e5)':'var(--text-muted,#94a3b8)'};">✦ AI Assistant</div>
          </div>
          <div id="rjd-toolbar">
            <div class="rjd-toolbar-left">
              <div class="rjd-toolbar-avatar">${escHtml(initials)}</div>
              <span id="rjd-username-display">${escHtml(currentUser.name)}</span>
            </div>
            <div style="display:flex;gap:6px;">
              <button id="rjd-quick-extract-btn" class="rjd-primary-btn" style="font-size:11px;padding:6px 12px;white-space:nowrap;">✦ Extract & Save</button>
              <button id="rjd-new-app-btn" class="rjd-primary-btn" style="background:var(--bg-secondary,#f8fafc);color:var(--accent-primary,#4f46e5);border:1.5px solid var(--accent-border,#c7d2fe);box-shadow:none;">+ New</button>
              <button id="rjd-refresh-btn" title="Refresh" ...>↻</button>
              <button id="rjd-settings-btn" title="Settings" ...>⚙</button>
            </div>
          </div>

          <div id="rjd-stats"></div>

          <!-- Session Bar -->
          <div id="rjd-session-bar">
            <div class="rjd-session-row">
              <span class="rjd-session-label">📅 Session:</span>
              <input type="date" id="rjd-working-date-input" class="rjd-session-input" max="${todayISO()}"/>
              <button id="rjd-working-date-today" class="rjd-session-btn">Today</button>
            </div>
            <div class="rjd-session-row">
              <span class="rjd-session-label">🎯 Target:</span>
              <select id="rjd-target-select" class="rjd-session-input">
                ${[10,15,20,25,30,35,40,50].map(n=>`<option value="${n}">${n} applications</option>`).join('')}
              </select>
              <span id="rjd-session-progress" style="font-weight:700;white-space:nowrap;color:var(--accent-primary,#4f46e5);font-size:12px;">0/30</span>
            </div>
            <div id="rjd-progress-bar-wrap">
              <div id="rjd-progress-bar"></div>
            </div>
          </div>

          <div id="rjd-filters">
            <input type="text" id="rjd-search-input" placeholder="Search company or title..." />
            <select id="rjd-status-filter">
              <option value="all">All Statuses</option>
              ${STATUSES.map(s=>`<option value="${s}">${s}</option>`).join('')}
            </select>
            <input type="date" id="rjd-date-filter" title="Filter by date" value="${filterDate || ''}" max="${todayISO()}" />
            <button id="rjd-export-csv-btn" title="Export Excel">Export XLSX</button>
          </div>

          <div id="rjd-table-wrap">
            <table id="rjd-table">
              <thead>
                <tr>
                  <th class="rjd-th" style="width:24px;">#</th>
                  <th class="rjd-th">Company</th>
                  <th class="rjd-th">Job Title</th>
                  <th class="rjd-th">URL</th>
                  <th class="rjd-th" title="Add Resume from Clipboard">Add</th>
                  <th class="rjd-th" title="Download Tailored Resume">DL</th>
                  <th class="rjd-th">Date</th>
                  <th class="rjd-th">Status</th>
                </tr>
              </thead>
              <tbody id="rjd-tbody"></tbody>
            </table>
          </div>
        </div>

        <div id="rjd-new-app-panel" style="display:none;flex-direction:column;flex:1;overflow:hidden;">
          <!-- Panel Header -->
          <div style="background:linear-gradient(135deg,#4f46e5,#7c3aed);padding:14px 18px;display:flex;align-items:center;gap:10px;flex-shrink:0;position:relative;overflow:hidden;">
            <div style="position:absolute;top:-20px;right:-10px;width:70px;height:70px;background:rgba(255,255,255,0.07);border-radius:50%;"></div>
            <button id="rjd-new-back" style="background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.25);color:#fff;border-radius:8px;padding:6px 12px;font-size:12px;cursor:pointer;font-family:inherit;font-weight:600;backdrop-filter:blur(8px);transition:all 0.2s;flex-shrink:0;">← Back</button>
            <div style="flex:1;">
              <div style="font-size:15px;font-weight:700;color:#fff;letter-spacing:-0.2px;">New Application</div>
              <div style="font-size:11px;color:rgba(255,255,255,0.65);margin-top:1px;" id="rjd-extract-status"></div>
            </div>
          </div>

          <!-- Scrollable Body -->
          <div style="flex:1;overflow-y:auto;padding:18px 18px 24px;">

            <!-- Extract Button -->
            <button id="rjd-extract-btn" style="width:100%;padding:14px 16px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;margin-bottom:20px;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 4px 16px rgba(79,70,229,0.3);transition:all 0.2s;letter-spacing:0.1px;">
              <span style="font-size:16px;">✦</span> Extract from Clipboard + Page URL
            </button>

            <!-- Divider -->
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:18px;">
              <div style="flex:1;height:1px;background:#e2e8f0;"></div>
              <span style="font-size:11px;color:#94a3b8;font-weight:600;white-space:nowrap;">OR FILL MANUALLY</span>
              <div style="flex:1;height:1px;background:#e2e8f0;"></div>
            </div>

            <!-- Company + Title side-by-side -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
              <div>
                <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.6px;margin-bottom:5px;">Company Name</label>
                <input type="text" id="rjd-new-company" placeholder="e.g. Google" style="width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:9px;font-size:13px;font-family:inherit;background:#fff !important;color:#1e293b !important;-webkit-text-fill-color:#1e293b !important;outline:none;transition:border-color 0.2s,box-shadow 0.2s;"/>
              </div>
              <div>
                <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.6px;margin-bottom:5px;">Job Title</label>
                <input type="text" id="rjd-new-title" placeholder="e.g. Data Analyst" style="width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:9px;font-size:13px;font-family:inherit;background:#fff !important;color:#1e293b !important;-webkit-text-fill-color:#1e293b !important;outline:none;transition:border-color 0.2s,box-shadow 0.2s;"/>
              </div>
            </div>

            <!-- Status -->
            <div style="margin-bottom:14px;">
              <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.6px;margin-bottom:5px;">Status</label>
              <div style="display:flex;gap:6px;flex-wrap:wrap;">
                ${STATUSES.map(s => `<button class="rjd-status-chip" data-val="${s}" style="padding:6px 12px;border-radius:20px;font-size:11px;font-weight:600;cursor:pointer;border:1.5px solid #e2e8f0;background:#f8fafc;color:#64748b;font-family:inherit;transition:all 0.15s;">${s}</button>`).join('')}
              </div>
              <input type="hidden" id="rjd-new-status" value="Applied"/>
            </div>

            <!-- Job URL -->
            <div style="margin-bottom:14px;">
              <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.6px;margin-bottom:5px;">Job URL</label>
              <input type="url" id="rjd-new-url" placeholder="Auto-filled or paste manually" style="width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:9px;font-size:13px;font-family:inherit;background:#fff !important;color:#1e293b !important;-webkit-text-fill-color:#1e293b !important;outline:none;transition:border-color 0.2s,box-shadow 0.2s;"/>
            </div>

            <!-- Job Description -->
            <div style="margin-bottom:20px;">
              <label style="display:block;font-size:10px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.6px;margin-bottom:5px;">Job Description</label>
              <textarea id="rjd-new-jd" placeholder="Auto-filled from clipboard, or paste JD here..." rows="6" style="width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:9px;font-size:12px;font-family:inherit;background:#fff !important;color:#1e293b !important;-webkit-text-fill-color:#1e293b !important;resize:vertical;outline:none;line-height:1.6;transition:border-color 0.2s,box-shadow 0.2s;"></textarea>
            </div>

            <!-- Save Button -->
            <button id="rjd-save-app-btn" style="width:100%;padding:13px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;border:none;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit;box-shadow:0 4px 14px rgba(79,70,229,0.3);transition:all 0.2s;letter-spacing:-0.1px;">
              💾 Save Application
            </button>

          </div>
        </div>

        <div id="rjd-detail-panel" style="display:none;flex-direction:column;flex:1;overflow:hidden;">
          <div class="rjd-panel-header">
            <button class="rjd-back-btn" id="rjd-detail-back">← Back</button>
            <span class="rjd-panel-title">Details</span>
          </div>
          <div class="rjd-panel-body">
            <div class="rjd-detail-row">
              <span class="rjd-detail-lbl">Company</span>
              <input type="text" id="rjd-detail-company-input" style="flex:1;padding:6px 10px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:13px;font-family:inherit;background:#fff;color:#1e293b;outline:none;" placeholder="Company Name"/>
            </div>
            <div class="rjd-detail-row">
              <span class="rjd-detail-lbl">Job Title</span>
              <input type="text" id="rjd-detail-title-input" style="flex:1;padding:6px 10px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:13px;font-family:inherit;background:#fff;color:#1e293b;outline:none;" placeholder="Job Title"/>
            </div>
            <div class="rjd-detail-row"><span class="rjd-detail-lbl">URL</span>
              <div style="display:flex;gap:6px;align-items:center;flex:1;">
                <input type="url" id="rjd-detail-url-input" style="flex:1;padding:4px 8px;border:1px solid #cbd5e0;border-radius:5px;font-size:12px;font-family:inherit;background:#fff;color:#1a202c;" placeholder="https://..."/>
                <a id="rjd-detail-url" target="_blank" class="rjd-url-link" style="white-space:nowrap;flex-shrink:0;">Open</a>
                <button id="rjd-copy-url-btn" style="padding:3px 8px;border:1px solid #e2e8f0;border-radius:5px;font-size:11px;background:#f8fafc;color:#4a5568;cursor:pointer;font-family:inherit;white-space:nowrap;flex-shrink:0;">Copy</button>
              </div>
            </div>
            <div class="rjd-detail-row"><span class="rjd-detail-lbl">Date</span><span id="rjd-detail-date"></span></div>
            <div class="rjd-detail-row"><span class="rjd-detail-lbl">Status</span><span id="rjd-detail-status"></span></div>
            <div class="rjd-detail-section"><div class="rjd-detail-lbl" style="display:flex;align-items:center;justify-content:space-between;">Resume</div><div id="rjd-detail-resume-section" style="margin-top:6px;"></div></div>
            <div class="rjd-detail-section">
              <div class="rjd-detail-lbl" style="display:flex;align-items:center;justify-content:space-between;">
                <span>Job Description</span>
                <button id="rjd-copy-jd-btn" style="padding:3px 8px;border:1px solid #e2e8f0;border-radius:5px;font-size:11px;background:#f8fafc;color:#4a5568;cursor:pointer;font-family:inherit;">Copy JD</button>
              </div>
              <pre id="rjd-detail-jd" class="rjd-jd-text"></pre>
            </div>
            <div class="rjd-detail-section">
              <div class="rjd-detail-lbl">Follow-up Date</div>
              <input type="date" id="rjd-detail-followup" style="width:100%;padding:6px 10px;border:1px solid #cbd5e0;border-radius:6px;font-size:12px;font-family:inherit;background:#fff !important;color:#1a202c !important;margin-top:4px;"/>
            </div>
            <div class="rjd-detail-section">
              <div class="rjd-detail-lbl">Notes</div>
              <textarea id="rjd-detail-notes" class="rjd-notes-input" rows="3"></textarea>
              <button id="rjd-save-notes-btn" class="rjd-action-btn" style="margin-top:6px;">Save Changes</button>
            </div>
            <div style="margin-top:12px;"><button id="rjd-delete-app-btn" class="rjd-delete-app-btn">Delete Application</button></div>
          </div>
        </div>

        <div id="rjd-resume-panel" style="display:none;flex-direction:column;flex:1;overflow:hidden;">
          <div class="rjd-panel-header">
            <button class="rjd-back-btn" id="rjd-resume-back">← Back</button>
            <span class="rjd-panel-title" id="rjd-resume-title">Resume</span>
          </div>
          <div style="flex:1;overflow:hidden;background:#fff;padding:12px;">
            <textarea id="rjd-resume-body" class="rjd-resume-body" style="width:100%;height:100%;border:1px solid #e2e8f0;border-radius:8px;padding:12px;font-size:12px;font-family:'SF Mono',monospace;line-height:1.6;color:#1e293b;resize:none;background:#f8fafc;"></textarea>
          </div>
          <div style="padding:10px 12px;border-top:1px solid #e2e8f0;flex-shrink:0;display:flex;gap:8px;">
            <button id="rjd-resume-save-btn" class="rjd-primary-btn" style="flex:1;">Save Changes</button>
            <button id="rjd-resume-copy-btn" class="rjd-action-btn rjd-secondary-btn" style="flex:0 0 auto;width:40px;" title="Copy to clipboard">📋</button>
          </div>
        </div>
      </div>`;

    renderTable();
    bindTrackerEvents();
    
    // Tab switching
    document.getElementById('rjd-tab-tracker').onclick = () => { currentTab = 'tracker'; renderTrackerScreen(); };
    document.getElementById('rjd-tab-assistant').onclick = () => { currentTab = 'assistant'; renderAssistantScreen(); };
  }

  // ════════════════════════════════════════
  // AI ASSISTANT SCREEN
  // ════════════════════════════════════════
  function renderAssistantScreen() {
    const main = document.getElementById('rjd-sidebar-content');
    if (!main) return;
    currentTab = 'assistant';

    main.innerHTML = `
      <div class="rjd-chat-container">
        <div id="rjd-tab-nav" style="display:flex;background:var(--bg-secondary,#f8fafc);border-bottom:1px solid var(--border-color,#e2e8f0);padding:4px 4px 0;">
          <div id="rjd-tab-tracker" style="flex:1;text-align:center;padding:10px;font-size:12px;font-weight:700;cursor:pointer;color:var(--text-muted,#94a3b8);">📊 Applications</div>
          <div id="rjd-tab-assistant" style="flex:1;text-align:center;padding:10px;font-size:12px;font-weight:700;cursor:pointer;border-bottom:2px solid var(--accent-primary,#4f46e5);color:var(--accent-primary,#4f46e5);">✦ AI Assistant</div>
        </div>

        <div id="rjd-chat-box">
          <div class="rjd-chat-greeting">
            <h1>How can I help you today?</h1>
          </div>
          <div id="rjd-chat-history"></div>
        </div>

        <div class="rjd-chat-input-wrap">
          <div class="rjd-chat-input-container">
            <textarea id="rjd-chat-input" placeholder="How can I help you today?" rows="1"></textarea>
            <button id="rjd-chat-send" title="Send Message">
              <span style="font-size:18px;">→</span>
            </button>
          </div>
        </div>
      </div>`;

    document.getElementById('rjd-tab-tracker').onclick = () => renderTrackerScreen();
    
    const input = document.getElementById('rjd-chat-input');
    if (input) {
      input.oninput = () => { input.style.height = 'auto'; input.style.height = (input.scrollHeight) + 'px'; };
      input.onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessageToAI(); } };
    }
    const sendBtn = document.getElementById('rjd-chat-send');
    if (sendBtn) sendBtn.onclick = () => sendMessageToAI();
  }

  async function sendMessageToAI() {
    const input = document.getElementById('rjd-chat-input');
    const text = input.value.trim();
    if (!text) return;
    
    input.value = '';
    input.style.height = 'auto';
    
    appendChatMessage('user', text);
    const loadingId = appendChatMessage('ai', '✦ Thinking...', true);
    
    try {
      const response = await processAIShortcut(text);
      updateChatMessage(loadingId, response);
    } catch (err) {
      updateChatMessage(loadingId, '✕ Error: ' + err.message);
    }
  }

  function appendChatMessage(role, text, isLoading = false) {
    const hist = document.getElementById('rjd-chat-history');
    if (!hist) return null;
    
    // Remove greeting on first message
    const greeting = document.querySelector('.rjd-chat-greeting');
    if (greeting) greeting.style.display = 'none';

    const id = 'msg-' + Date.now();
    const isUser = role === 'user';
    const msg = document.createElement('div');
    msg.id = id;
    msg.className = 'rjd-chat-msg';
    if (isUser) msg.style.justifyContent = 'flex-end';
    
    msg.innerHTML = `
      <div class="${isUser ? 'rjd-chat-msg-user' : 'rjd-chat-msg-ai'}">
        ${formatMsg(text)}
      </div>`;
    
    hist.appendChild(msg);
    // Scroll correctly
    const scrollBox = document.getElementById('rjd-chat-box');
    if (scrollBox) scrollBox.scrollTop = scrollBox.scrollHeight;
    return id;
  }

  function updateChatMessage(id, text) {
    const msg = document.getElementById(id);
    if (!msg) return;
    const bubble = msg.querySelector('div');
    if (bubble) bubble.innerHTML = formatMsg(text);
    const scrollBox = document.getElementById('rjd-chat-box');
    if (scrollBox) scrollBox.scrollTop = scrollBox.scrollHeight;
  }

  /**
   * Simple Markdown-ish Formatter for Chat
   */
  function formatMsg(text) {
    if (!text) return '';
    let html = escHtml(text);
    
    // Bold: **text**
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Italics: *text* (only if not a bullet)
    // We do italics after bullets to avoid conflict
    
    // Bullets: ^* or ^- 
    const lines = html.split('\n').map(l => {
      let line = l.trim();
      if (line.startsWith('* ') || line.startsWith('- ') || line.startsWith('• ')) {
        return `<div style="display:flex; gap:6px; margin-bottom:4px;"><span>•</span><span>${line.substring(2)}</span></div>`;
      }
      return l;
    });

    html = lines.join('\n').replace(/\n/g, '<br>');
    return html;
  }

  function bindTrackerEvents() {
    document.getElementById('rjd-settings-btn').addEventListener('click', () => renderSettingsScreen('tracker'));
    document.getElementById('rjd-refresh-btn').addEventListener('click', async () => {
      const btn = document.getElementById('rjd-refresh-btn');
      btn.style.opacity = '0.5';
      btn.disabled = true;
      try {
        applications = await dbLoadApps();
        renderTable();
        showToast('Refreshed ✓');
      } catch(e) {
        showToast('Refresh failed', true);
      }
      btn.style.opacity = '1';
      btn.disabled = false;
    });
    document.getElementById('rjd-new-app-btn').addEventListener('click', () => showNewAppPanel(false));
    document.getElementById('rjd-new-back').addEventListener('click', hideNewAppPanel);
    document.getElementById('rjd-detail-back').addEventListener('click', hideAppDetail);
    document.getElementById('rjd-resume-back').addEventListener('click', hideResumeDetail);

    document.getElementById('rjd-search-input').addEventListener('input', (e) => { filterSearch = e.target.value; renderTable(); });
    document.getElementById('rjd-status-filter').addEventListener('change', (e) => { filterStatus = e.target.value; renderTable(); });
    document.getElementById('rjd-date-filter').addEventListener('change', (e) => { filterDate = e.target.value; renderTable(); });

    // ── WORKING DATE picker ──
    function setWorkingDate(iso) {
      workingDate = iso;
      const input = document.getElementById('rjd-working-date-input');
      if (input) input.value = iso;
      const _s = chromeStore(); if (_s) _s.set({ rjd_working_date: iso });
      // Update stats to reflect new working date
      updateStatsBar();
    }
    function updateStatsBar() {
      const todayApps = applications.filter(a => a.dateKey === todayKey()).length;
      const el = document.getElementById('rjd-today-count');
      if (el) el.textContent = todayApps;
    }
    // Set the input to reflect already-loaded workingDate
    const _wdInput = document.getElementById('rjd-working-date-input');
    if (_wdInput && workingDate) _wdInput.value = workingDate;
    document.getElementById('rjd-working-date-input').addEventListener('change', e => {
      setWorkingDate(e.target.value);
    });
    document.getElementById('rjd-working-date-today').addEventListener('click', () => {
      const d = new Date();
      const iso = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
      setWorkingDate(iso);
    });
    document.getElementById('rjd-target-select').addEventListener('change', e => {
      localStorage.setItem('rjd_session_target', e.target.value);
      updateSessionProgress();
    });
    // Init target select value
    const _tSel = document.getElementById('rjd-target-select');
    if (_tSel) _tSel.value = String(getSessionTarget());
    updateSessionProgress();

    // ── RESUME MODAL ACTIONS ──
    document.getElementById('rjd-resume-copy-btn').addEventListener('click', () => {
      const text = document.getElementById('rjd-resume-body').value;
      navigator.clipboard.writeText(text).then(() => showToast('Resume copied')).catch(() => showToast('Copy failed', true));
    });

    document.getElementById('rjd-resume-save-btn').addEventListener('click', async () => {
      const appId = currentDetailId || applications.find(a => a.company === document.getElementById('rjd-resume-title').textContent.replace('Resume — ', ''))?.id;
      if (!appId) {
        // Fallback for when currentDetailId is lost
        const activeApp = applications.find(a => (a.company || 'Application') === document.getElementById('rjd-resume-title').textContent.replace('Resume — ', ''));
        if (activeApp) saveResumeText(activeApp);
        else showToast('Could not identify application', true);
        return;
      }
      const app = applications.find(a => a.id === appId);
      if (app) saveResumeText(app);
    });

    async function saveResumeText(app) {
      const btn = document.getElementById('rjd-resume-save-btn');
      const text = document.getElementById('rjd-resume-body').value.trim();
      if (!text) { showToast('Content cannot be empty', true); return; }
      const old = btn.textContent;
      btn.textContent = 'Saving...'; btn.disabled = true;
      try {
        app.resume = text;
        await dbUpdateApp(app);
        showToast('Resume saved ✓');
        renderTable();
      } catch (err) {
        showToast('Save failed', true);
      } finally {
        btn.textContent = old; btn.disabled = false;
      }
    }

    // Quick extract & save
    let _extracting = false;
    document.getElementById('rjd-quick-extract-btn').addEventListener('click', async () => {
      if (_extracting) return;
      _extracting = true;
      const btn = document.getElementById('rjd-quick-extract-btn');
      btn.textContent = 'Extracting...'; btn.disabled = true;

      const pageUrl  = window.location.href;
      let company    = '';
      let jobTitle   = '';
      let clipText   = '';

      // Try to read clipboard
      try { clipText = await navigator.clipboard.readText(); } catch(e) {}
      clipText = clipText || '';

      // Fall back to page body text if clipboard is empty (same behavior as runExtract)
      if (!clipText.trim()) {
        clipText = document.body.innerText.substring(0, 8000);
      }

      // Load Gemini key if not yet in memory
      if (!GEMINI_KEY) await new Promise(r => loadGeminiKey(k => { GEMINI_KEY = k; r(); }));
      // Try Gemini extraction if key exists and we have content to parse
      if (GEMINI_KEY && GEMINI_KEY.trim() && clipText.trim()) {
        try {
          const result = await extractWithGemini(clipText, pageUrl);
          company  = result.company_name || '';
          jobTitle = result.job_title    || '';

          // Block ineligible jobs
          if (result.isEligible === false) {
            showToast('✕ Not Eligible: ' + (result.eligibilityReason || 'Exclusion criteria met'), true);
            btn.textContent = '✦ Extract & Save'; btn.disabled = false; _extracting = false;
            return;
          }
        } catch(e) {
          console.warn('[AI Blaze] Quick extract failed:', e.message);
          // Extraction failed — will open form for manual fill
        }
      }

      // Duplicate check (only if we got something)
      if (company || jobTitle) {
        const dupByUrl   = applications.find(a => a.url && a.url === pageUrl);
        // Warning fix #1: normalise both sides with trim() + toLowerCase() for reliable matching
        const dupByTitle = applications.find(a =>
          a.company?.toLowerCase().trim() === company.toLowerCase().trim() &&
          a.jobTitle?.toLowerCase().trim() === jobTitle.toLowerCase().trim()
        );
        if (dupByUrl) {
          showToast('Already saved: ' + (dupByUrl.company || dupByUrl.jobTitle), true);
          btn.textContent = '✦ Extract & Save'; btn.disabled = false; _extracting = false;
          return;
        }
        if (dupByTitle) {
          showToast('Possible duplicate: ' + dupByTitle.company + ' — ' + dupByTitle.jobTitle, true);
          btn.textContent = '✦ Extract & Save'; btn.disabled = false; _extracting = false;
          return;
        }
      }

      // If we got company + title → save directly
      if (company && jobTitle) {
        const app = {
          id: crypto.randomUUID(), company, jobTitle,
          url: pageUrl, jd: clipText, resume: '',
          status: 'Applied', date: today(), dateRaw: new Date().toISOString(),
          dateKey: todayKey(), notes: '', followUpDate: ''
        };
        const ok = await dbSaveApp(app);
        if (ok) {
          applications.push(app);
          renderTable();
          showToast('Saved: ' + company + ' — ' + jobTitle);
        } else {
          showToast('Save failed — check connection', true);
        }
      } else {
        // Could not extract — open New Application form pre-filled with what we have
        showNewAppPanel(false);
        // Pre-fill whatever we could get
        const co = document.getElementById('rjd-new-company');
        const ti = document.getElementById('rjd-new-title');
        const ur = document.getElementById('rjd-new-url');
        const jd = document.getElementById('rjd-new-jd');
        if (co) co.value = company || '';
        if (ti) ti.value = jobTitle || '';
        if (ur) ur.value = pageUrl;
        if (jd) jd.value = clipText || '';
        // Show helpful hint
        const st = document.getElementById('rjd-extract-status');
        if (st) {
          st.style.color = '#975a16';
          st.textContent = !GEMINI_KEY
            ? 'No API key — fill details manually or add key in ⚙ Settings'
            : !clipText.trim()
            ? 'Clipboard empty — URL pre-filled, add company and title'
            : 'Could not extract — please fill in the details';
        }
      }

      btn.textContent = '✦ Extract & Save'; btn.disabled = false;
      _extracting = false;
    });

    // Extract in panel
    document.getElementById('rjd-extract-btn').addEventListener('click', () => runExtract());

    // Save new app — loading guard prevents double-submit (#17)
    let _saving = false;
    document.getElementById('rjd-save-app-btn').addEventListener('click', async () => {
      if (_saving) return;
      const company  = document.getElementById('rjd-new-company').value.trim();
      const jobTitle = document.getElementById('rjd-new-title').value.trim();
      const url      = document.getElementById('rjd-new-url').value.trim();
      const jd       = document.getElementById('rjd-new-jd').value.trim();
      const status   = document.getElementById('rjd-new-status')?.value || 'Applied';
      if (!company && !jobTitle) { showToast('Enter at least company or job title', true); return; }
      const dupByUrl   = url && applications.find(a => a.url && a.url === url);
      const dupByTitle = company && jobTitle && applications.find(a =>
        a.company?.toLowerCase().trim() === company.toLowerCase() &&
        a.jobTitle?.toLowerCase().trim() === jobTitle.toLowerCase()
      );
      if (dupByUrl)   { showToast('Already saved: ' + (dupByUrl.company || dupByUrl.jobTitle), true); return; }
      if (dupByTitle) { showToast('Possible duplicate: ' + dupByTitle.company + ' — ' + dupByTitle.jobTitle, true); return; }
      _saving = true;
      const saveBtn = document.getElementById('rjd-save-app-btn');
      if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = '⏳ Saving...'; }
      const app = {
        id: crypto.randomUUID(), company, jobTitle, url, jd, resume: '',
        status, date: today(), dateRaw: new Date().toISOString(), dateKey: todayKey(), notes: '', followUpDate: ''
      };
      const ok = await dbSaveApp(app);
      _saving = false;
      if (saveBtn) { saveBtn.disabled = false; saveBtn.innerHTML = '💾 Save Application'; }
      if (ok) {
        applications.push(app);
        hideNewAppPanel();
        renderTable();
        showToast('✓ Application saved — ' + company);
      } else { showToast('Save failed — check connection', true); }
    });

    // Detail panel events
    document.getElementById('rjd-detail-panel').addEventListener('click', async (e) => {
      if (e.target.id === 'rjd-save-notes-btn') {
        const app = applications.find(a=>a.id===currentDetailId);
        if (app) {
          app.company = document.getElementById('rjd-detail-company-input').value.trim();
          app.jobTitle = document.getElementById('rjd-detail-title-input').value.trim();
          app.notes = document.getElementById('rjd-detail-notes').value;
          app.followUpDate = document.getElementById('rjd-detail-followup').value || '';
          const newUrl = (document.getElementById('rjd-detail-url-input')?.value || '').trim();
          app.url = newUrl;
          await dbUpdateApp(app);
          showToast('Changes Saved ✓');
          renderTable();
        }
      }
      if (e.target.id === 'rjd-delete-app-btn') {
        if (confirm('Delete this application?')) {
          await dbDeleteApp(currentDetailId);
          applications = applications.filter(a=>a.id!==currentDetailId);
          hideAppDetail(); renderTable(); showToast('Deleted');
        }
      }
    });

    // (removed duplicate copy handler — correct one is bound at line 2149)

    // Export XLSX — inject xlsxbuilder.js on demand (fix #9: removed from content_scripts to avoid global scope pollution)
    document.getElementById('rjd-export-csv-btn').addEventListener('click', async () => {
      if (applications.length === 0) { showToast('No applications to export', true); return; }
      // Lazy-load xlsxbuilder if not already present
      if (typeof window.buildXLSX !== 'function') {
        await new Promise((resolve, reject) => {
          const s = document.createElement('script');
          s.src = chrome.runtime.getURL('src/lib/xlsxbuilder.js');
          s.onload = resolve;
          s.onerror = () => reject(new Error('Failed to load xlsxbuilder.js'));
          document.head.appendChild(s);
        });
      }
      showToast('Preparing export...');
      try {
        const now = new Date();
        const statusStyleMap = { 'Applied':2,'Interview Scheduled':3,'Interview Done':4,'Offer':5,'Rejected':6,'Skipped':7 };
        const numCols = 8;
        const colWidths = [5, 22, 30, 28, 20, 14, 45, 55];
        const rowHeights = {};
        const sheetRows = [];
        sheetRows.push([{ v: 'Job Application Report — ' + currentUser.name, t:'s', s:15 }, ...Array(numCols-1).fill(null)]);
        rowHeights[0] = 30;
        sheetRows.push([{ v: 'Exported on ' + now.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'}) + '   ·   Total: ' + applications.length, t:'s', s:16 }, ...Array(numCols-1).fill(null)]);
        rowHeights[1] = 18;
        sheetRows.push(Array(numCols).fill(null)); rowHeights[2] = 6;
        const headers = ['#','Company','Job Title','Job URL','Status','Date Applied','Resume Text','Job Description'];
        sheetRows.push(headers.map(h=>({ v:h, t:'s', s:1 }))); rowHeights[3] = 22;
        applications.forEach((a,i) => {
          const isAlt = i%2===1; const sStat = statusStyleMap[a.status]||2;
          const def=isAlt?8:0, wrap=isAlt?10:9, ctr=isAlt?14:13;
          const urlCell = a.url ? { v:'Open Link', t:'s', s:11, url:a.url } : { v:'—', t:'s', s:def };
          rowHeights[4+i] = (a.resume||a.jd) ? 90 : 18;
          sheetRows.push([
            { v:String(i+1), t:'n', s:ctr }, { v:a.company||'—', t:'s', s:def },
            { v:a.jobTitle||'—', t:'s', s:def }, urlCell, { v:a.status||'—', t:'s', s:sStat },
            { v:a.date||'—', t:'s', s:ctr }, { v:a.resume||'', t:'s', s:wrap }, { v:a.jd||'', t:'s', s:wrap },
          ]);
        });
        const STATUSES2 = ['Applied','Interview Scheduled','Interview Done','Offer','Rejected','Skipped'];
        const statusCounts = {}; STATUSES2.forEach(s=>{ statusCounts[s]=applications.filter(a=>a.status===s).length; });
        const s2rows = []; const s2heights = {};
        s2rows.push([{ v:'Summary Dashboard', t:'s', s:15 }, null,null,null,null,null]); s2heights[0]=28;
        s2rows.push([{ v:'User: '+currentUser.name+'   ·   '+now.toLocaleDateString(), t:'s', s:16 }, null,null,null,null,null]); s2heights[1]=16;
        s2rows.push(Array(6).fill(null)); s2heights[2]=10;
        const kpis=[{label:'Total',value:String(applications.length)},{label:'This Week',value:String(applications.filter(a=>{const d=new Date(a.dateRaw);return(now-d)<=7*86400000;}).length)},{label:'Interviews',value:String((statusCounts['Interview Scheduled']||0)+(statusCounts['Interview Done']||0))},{label:'Offers',value:String(statusCounts['Offer']||0)},{label:'With Resume',value:String(applications.filter(a=>a.resume).length)},{label:'Success %',value:applications.length>0?Math.round(((statusCounts['Offer']||0)/applications.length)*100)+'%':'0%'}];
        const kpiStyles=[17,22,23,24,25,26];
        s2rows.push(kpis.map((k,i)=>({ v:k.label, t:'s', s:kpiStyles[i] }))); s2heights[3]=18;
        s2rows.push(kpis.map(k=>({ v:k.value, t:'s', s:18 }))); s2heights[4]=40;
        s2rows.push(Array(6).fill(null)); s2heights[5]=12;
        s2rows.push([{v:'Status',t:'s',s:19},{v:'Count',t:'s',s:19},{v:'%',t:'s',s:19},null,null,null]); s2heights[6]=20;
        STATUSES2.forEach((st,i)=>{ const c=statusCounts[st]||0; const pct=applications.length>0?((c/applications.length)*100).toFixed(1)+'%':'0%'; const ss=statusStyleMap[st]||2; s2rows.push([{v:st,t:'s',s:ss},{v:String(c),t:'n',s:13},{v:pct,t:'s',s:13},null,null,null]); s2heights[7+i]=18; });
        const bytes = await window.buildXLSX([
          { name:'Applications', headers, rows:sheetRows, colWidths, merges:['A1:H1','A2:H2'], rowHeights },
          { name:'Summary', headers:[], rows:s2rows, colWidths:[22,12,12,12,12,12], merges:['A1:F1','A2:F2'], rowHeights:s2heights }
        ]);
        const blob = new Blob([bytes], { type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url; link.download = currentUser.name + '_' + now.toISOString().slice(0,10) + '.xlsx';
        document.body.appendChild(link); link.click(); document.body.removeChild(link);
        URL.revokeObjectURL(url); showToast('Excel exported ✓');
      } catch(err) { showToast('Export failed: ' + err.message, true); }
    });
  }


  // ── BUILD SIDEBAR ──
  function applyTheme(theme) {
    const sidebar = document.getElementById('rjd-sidebar');
    if (!sidebar) return;
    sidebar.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');
    const s = chromeStore(); if (s) s.set({ rjd_theme: theme });
  }


    /**
     * Process AI for shortcuts without polluting chat history (or as hidden turn)
     */
    async function processAIShortcut(prompt) {
      try {
        const engine = localStorage.getItem('rjd_extraction_engine') || 'gemini';
        showToast(`AI Working (${engine})...`);
        
        // Load context (Profile)
        const profile = await loadResumeProfileDB();
        
        let contextPrefix = "";
        if (profile && profile.name) {
          contextPrefix = `Context: User Name is ${profile.name}. Current Title: ${profile.title || 'N/A'}. Education: ${profile.education || 'N/A'}. `;
        }

        // Build context-aware prompt with strict formatting instructions
        const systemInstruction = `
Instruction: You are an expert Resume Writer and Data Engineer Career Coach. 
When generating or tailoring a resume, YOU MUST use EXACTLY these markers for sections:
[professional summary] - for the summary section.
[technical skills] - for the skills section. Each skill category must end with a colon (e.g., "Languages: Python, SQL").
[professional experience] - for the experience section. Format each job header as: "Company | Location | Job Title | Date Range". Use "• " bullets for achievements.

Return the resume content formatted clearly between these markers.
        `;
        
        const fullPrompt = `${systemInstruction}\n\n${contextPrefix}\n\nUser Request: ${prompt}`;
        
        // Call the appropriate engine
        let result = '';
        if (engine === 'ollama') {
          throw new Error('Ollama is no longer supported. Switch to Gemini in Settings.');
        } else {
          if (!GEMINI_KEY) {
             // Try to load if not yet available
             await new Promise(resolve => loadGeminiKey(k => { GEMINI_KEY = k; resolve(); }));
          }
          if (!GEMINI_KEY) throw new Error('Gemini API key missing. Please set it in Settings.');
          result = await callGeminiBlaze(GEMINI_KEY, fullPrompt);
        }
        
        return result || "AI error: No response";
      } catch (err) {
        console.error("Shortcut AI Error:", err);
        return `[AI Error: ${err.message}]`;
      }
    }

  // Cleanup and toggle
  function toggleSidebar(force) {
    const sidebar = document.getElementById('rjd-sidebar');
    if (sidebar) {
      if (force === true) { sidebar.classList.add('open'); isSidebarOpen = true; }
      else if (force === false) { sidebar.classList.remove('open'); isSidebarOpen = false; }
      else {
        sidebar.classList.toggle('open');
        isSidebarOpen = sidebar.classList.contains('open');
      }
    }
  }

  function buildSidebar() {
    const style = document.createElement('style');
    style.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    `;
    document.head.appendChild(style);

    // Restore saved theme preference or auto-detect
    const s2 = chromeStore();
    if (s2) {
      s2.get('rjd_theme', r => {
        const saved = r.rjd_theme || 'auto';
        if (saved === 'dark') {
          applyTheme('dark');
        } else if (saved === 'light') {
          applyTheme('light');
        } else {
          // Auto — follow OS
          const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
          applyTheme(prefersDark ? 'dark' : 'light');
        }
      });
    }

    const sidebar = document.createElement('div');
    sidebar.id = 'rjd-sidebar';
    sidebar.innerHTML = `
      <div id="rjd-header">
        <h2>Job Application Tracker</h2>
        <button id="rjd-close">✕</button>
      </div>
      <div id="rjd-sidebar-content" style="display:flex;flex-direction:column;flex:1;overflow:hidden;"></div>`;
    document.body.appendChild(sidebar);

    // ── FLOATING TRACK BUTTON ──
    const toggle = document.createElement('div');
    toggle.id = 'rjd-toggle';
    toggle.innerHTML = `
      <div id="rjd-toggle-icon" style="width:52px;height:52px;background:linear-gradient(135deg,#4f46e5,#7c3aed);border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(79,70,229,0.4);cursor:pointer;transition:all 0.2s;position:relative;">
        <img src="${(typeof chrome !== 'undefined' && chrome.runtime) ? chrome.runtime.getURL('/public/icons/icon128.png') : ''}" style="width:26px; height:26px; object-fit:contain; border-radius:6px; pointer-events:none;"/>
        <div id="rjd-toggle-badge" style="display:none;position:absolute;top:-4px;right:-4px;background:#dc2626;color:#fff;border-radius:50%;width:20px;height:20px;font-size:10px;font-weight:800;align-items:center;justify-content:center;border:2px solid #fff;">0</div>
      </div>
      <div id="rjd-queue-badge" style="display:none;position:absolute;bottom:-4px;right:-4px;background:#f59e0b;color:#fff;border-radius:50%;width:18px;height:18px;font-size:9px;font-weight:800;align-items:center;justify-content:center;border:2px solid #fff;">0</div>
    `;
    // Draggable positioning (slide up/down on the right edge)
    let _isDragging = false, _startY = 0, _startTop = 0;
    let _toggleTop = window.innerHeight / 2 - 26; // initial vertical center
    toggle.style.cssText = `position:fixed!important;right:12px!important;top:${_toggleTop}px;z-index:2147483647!important;cursor:grab;user-select:none;`;

    toggle.addEventListener('mousedown', (e) => {
      _isDragging = false;
      _startY = e.clientY;
      _startTop = _toggleTop;
      const onMove = (em) => {
        const dy = em.clientY - _startY;
        if (Math.abs(dy) > 4) _isDragging = true;
        _toggleTop = Math.max(10, Math.min(window.innerHeight - 70, _startTop + dy));
        toggle.style.top = _toggleTop + 'px';
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        toggle.style.cursor = 'grab';
        if (!_isDragging) handleToggleClick();
        // Persist position safely
        try {
          if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
            const s3 = chromeStore();
            if (s3) s3.set({ rjd_toggle_top: _toggleTop });
          }
        } catch(e) {}
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    // Touch drag support
    toggle.addEventListener('touchstart', (e) => {
      _isDragging = false;
      _startY = e.touches[0].clientY;
      _startTop = _toggleTop;
    }, { passive: true });
    toggle.addEventListener('touchmove', (e) => {
      const dy = e.touches[0].clientY - _startY;
      if (Math.abs(dy) > 4) _isDragging = true;
      _toggleTop = Math.max(10, Math.min(window.innerHeight - 70, _startTop + dy));
      toggle.style.top = _toggleTop + 'px';
    }, { passive: true });
    toggle.addEventListener('touchend', () => { if (!_isDragging) handleToggleClick(); });

    function handleToggleClick() {
      if (!currentUser) {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
          window.open(chrome.runtime.getURL('src/pages/app.html'), '_blank');
        }
        return;
      }
      sidebar.classList.toggle('open');
      if (!sidebar.classList.contains('open')) return;
      if (applications.length > 0) { renderTrackerScreen(); return; }
      showLoading('Loading...');
      dbLoadApps().then(apps => { applications = apps; renderTrackerScreen(); }).catch(() => renderTrackerScreen());
    }

    // Restore saved position
    const s2b = chromeStore();
    if (s2b) s2b.get('rjd_toggle_top', r => {
      if (r.rjd_toggle_top) { _toggleTop = r.rjd_toggle_top; toggle.style.top = _toggleTop + 'px'; }
    });

    // Hover effect
    const icon = toggle.querySelector('#rjd-toggle-icon');
    toggle.addEventListener('mouseenter', () => { if (icon) icon.style.transform = 'scale(1.1)'; });
    toggle.addEventListener('mouseleave', () => { if (icon) icon.style.transform = ''; });
    
    // External open hook for popup/keyboard shortcut
    toggle.addEventListener('rjd-external-open', handleToggleClick);

    document.body.appendChild(toggle);

    const toast = document.createElement('div');
    toast.id = 'rjd-toast';
    document.body.appendChild(toast);

    document.getElementById('rjd-close').addEventListener('click', () => sidebar.classList.remove('open'));

    // Flush offline queue on load
    setTimeout(() => flushQueue(), 2000);
    // Check for existing queue items
    getQueue(q => updateQueueBadge(q.length));
  }

  // ── KEYBOARD SHORTCUTS ──
  // Listen for commands forwarded from background.js via CustomEvent
  window.addEventListener('rjd-command', (e) => {
    const action  = e.detail && e.detail.action;
    const sidebar = document.getElementById('rjd-sidebar');
    const isOpen  = sidebar && sidebar.classList.contains('open');
    if (action === 'toggle_sidebar') {
      const tg = document.getElementById('rjd-toggle');
      if (tg) tg.dispatchEvent(new Event('rjd-external-open'));
    } else if (action === 'extract_save' && isOpen) {
      document.getElementById('rjd-quick-extract-btn') && document.getElementById('rjd-quick-extract-btn').click();
    } else if (action === 'new_app' && isOpen) {
      document.getElementById('rjd-new-app-btn') && document.getElementById('rjd-new-app-btn').click();
    } else if (action === 'open_settings' && isOpen && currentUser) {
      renderSettingsScreen('tracker');
    }
  });

  // Escape key — close panel or sidebar
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    const sidebar = document.getElementById('rjd-sidebar');
    if (!sidebar || !sidebar.classList.contains('open')) return;
    // Close detail/new/resume panels first, then sidebar
    const detail = document.getElementById('rjd-detail-panel');
    const newApp  = document.getElementById('rjd-new-app-panel');
    const resume  = document.getElementById('rjd-resume-panel');
    if (resume  && resume.style.display  !== 'none') { hideResumeDetail(); return; }
    if (detail  && detail.style.display  !== 'none') { hideAppDetail();    return; }
    if (newApp  && newApp.style.display  !== 'none') { hideNewAppPanel();  return; }
    sidebar.classList.remove('open');
  });

  buildSidebar();

  // ── SESSION MANAGEMENT ──
  function applySession(sess) {
    const tog = document.getElementById('rjd-toggle');
    if (sess && sess.token && sess.user) {
      // Validate project before applying
      if (!verifyTokenProject(sess.token)) {
        clearSession();
        return;
      }
      sessionToken        = sess.token;
      sessionRefreshToken = sess.refreshToken || '';
      currentUser         = sess.user;
      loadGeminiKey(k => { GEMINI_KEY = k || ''; });
      filterDate          = todayISO(); // Default to today in the list
      if (tog) tog.classList.add('rjd-visible');
      updateTrackBadge();
      // Preload apps silently
      dbLoadApps().then(apps => { applications = apps; updateTrackBadge(); }).catch(() => {});
      // Proactive refresh every 50m
      if (!window._rjdRefreshTimer) {
        window._rjdRefreshTimer = setInterval(() => refreshSession(), 50 * 60 * 1000);
      }
    } else {
      currentUser = null;
      applications = [];
      if (tog) tog.classList.remove('rjd-visible');
    }
  }

  // Safe chrome API check
  const hasChromeStorage = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  const hasChromeRuntime = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage;

  // On page load — load working date AND session together so workingDate is set before any save
  if (hasChromeStorage) {
    chrome.storage.local.get(['rjd_session', 'rjd_working_date'], r => {
      if (chrome.runtime.lastError) return;
      // Set workingDate FIRST before applySession renders the sidebar
      if (r.rjd_working_date) {
        workingDate = r.rjd_working_date;
      }
      applySession(r.rjd_session || null);
    });
  }

  // Listen for login/logout from background.js
  if (hasChromeRuntime) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.action === 'session_saved') {
        applySession(msg.payload);
      } else if (msg.action === 'session_cleared') {
        applySession(null);
        const sidebar = document.getElementById('rjd-sidebar');
        if (sidebar) sidebar.classList.remove('open');
      }
    });
  }

  // Fallback poll every 3 seconds
  if (hasChromeStorage) {
    const _poll = setInterval(() => {
      try {
        // Stop polling if extension context is gone (happens after extension reload)
        if (!isContextValid()) {
          console.log('AI Blaze: Stopping session poll — context invalidated.');
          clearInterval(_poll);
          const tog = document.getElementById('rjd-toggle');
          if (tog) tog.title = 'Extension reloaded — please refresh the page';
          return;
        }
        chrome.storage.local.get('rjd_session', r => {
          if (chrome.runtime.lastError) { clearInterval(_poll); return; }
          const sess = r.rjd_session || null;
          const hasToken = sess && (sess.token || sess.access_token);
          if (sess && hasToken && sess.user && !currentUser) {
            applySession(sess);
          } else if ((!sess || !hasToken) && currentUser) {
            applySession(null);
          }
        });
      } catch(e) { clearInterval(_poll); }
    }, 3000);
  }

  // -- INTEGRATED RESUME ENGINE --
  async function generateIntegratedResume(app) {
    // Load profile from chrome.storage.local (shared across all sites)
    const p = await new Promise(resolve => {
      const s = chromeStore();
      if (s) {
        s.get('rjd_resume_profile', r => {
          if (chrome.runtime.lastError) {
            resolve(JSON.parse(localStorage.getItem('rjd_resume_profile') || '{}'));
            return;
          }
          resolve(r.rjd_resume_profile || JSON.parse(localStorage.getItem('rjd_resume_profile') || '{}'));
        });
      } else {
        resolve(JSON.parse(localStorage.getItem('rjd_resume_profile') || '{}'));
      }
    });
    if (!p.name) {
      showToast('Please fill out your Resume Profile in Settings first!', true);
      renderSettingsScreen('tracker');
      return;
    }
    try {
      if (window.ResumeEngine) {
        await window.ResumeEngine.generate(app, p);
      } else {
        showToast('Resume engine not loaded. Please refresh.', true);
      }
    } catch (err) {
      console.error(err);
      showToast('Download failed: ' + err.message, true);
    }
  }

  // ── COPILOT BRIDGE ──
  window.addEventListener('message', async (e) => {
    // 1. Open Sidebar & Focus Input
    if (e.data?.type === 'AI_BLAZE_OPEN_SIDEBAR') {
      const sidebar = document.getElementById('rjd-sidebar');
      if (!isSidebarOpen) toggleSidebar(true);
      
      // Force switch to Assistant tab
      renderAssistantScreen();
      
      setTimeout(() => {
        const input = document.getElementById('rjd-chat-input');
        if (input) {
          input.value = e.data.prompt || '';
          input.focus();
          // Adjust height
          input.style.height = 'auto';
          input.style.height = input.scrollHeight + 'px';
          // Auto-trigger if prompt is provided
          if (e.data.prompt) document.getElementById('rjd-chat-send').click();
        }
      }, 300);
    }

    // 2. Direct Shortcut Replacement / Quick Action
    if (e.data?.type === 'AI_BLAZE_QUICK_ACTION') {
      const { action, text, prompt: customPrompt, targetEl } = e.data;
      
      // If it's NOT a replacement, it might still want to open sidebar
      if (!targetEl && !isSidebarOpen) {
        toggleSidebar(true);
        renderAssistantScreen();
      }

      // Process
      try {
        const engine = localStorage.getItem('rjd_extraction_engine') || 'gemini';
        let finalPrompt = customPrompt;
        if (!finalPrompt) {
          if (action === 'fix') finalPrompt = `Fix grammar, spelling, and professionalize the following text: "${text}"`;
          else if (action === 'summarize') finalPrompt = `Summarize the following text concisely: "${text}"`;
          else finalPrompt = text;
        }

        const responseText = await processAIShortcut(finalPrompt);
        window.postMessage({ type: 'AI_BLAZE_RESPONSE_READY', text: responseText }, '*');
        
        // If sidebar is open, show in Chat too if not replacement
        if (!targetEl && currentTab === 'assistant') {
          appendChatMessage('ai', responseText);
        }
      } catch (err) {
        console.error('Copilot Bridge Error:', err);
        window.postMessage({ type: 'AI_BLAZE_RESPONSE_READY', text: '✕ AI Error: ' + err.message }, '*');
      }
    }
  });

})();